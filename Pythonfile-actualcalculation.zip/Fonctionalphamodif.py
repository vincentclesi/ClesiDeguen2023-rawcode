# -*- coding: utf-8 -*-
"""
Created on Tue Jan 18 19:09:26 2022

@author: vince
"""
import fonctions as fct
import numpy as np
import DataFischer as Fis
import Fonctiondefc as acc
Cpm = 1000;# Chaleur spécifiqque métal en J/kg.K, même valeur que dans le rapport
Cps = 500; # Cahleur spécifique silicate en J/kg.K, même valeur que dans le rapport
mu_sil = 1e18;
D_sil= 1e-6;
Rnf=3470000
def CalculTparam(Fe,Ni,Co,V,Cr,Si,O,Px,Tx,Pn,Rn,coeff,step):
    l=len(Fe)
    
    rho0th=[7019,7900,8900,2210,6100,7190,365.45] #on se fait pas trop chier au début avec les interactions
    alphaSi=-0.91
    alphaO=-1.3
    rho0=np.zeros(len(Fe))
    for i in range(l):
        
        rhoint=rho0th[0]*Fe[i]+rho0th[1]*Ni[i]+rho0th[2]*Co[i]+rho0th[4]*V[i]+rho0th[5]*Cr[i]
        rho0[i]=rhoint*np.exp(alphaSi*Si[i])*np.exp(alphaO*O[i])
    Tcmb=np.zeros(l)
    rho1=np.zeros(l)
    
    T,rho=fct.T_simpleanalytique(Px,Tx,Pn,coeff,rho0)
    for i in range(l):
        Tcmb[i]=T[i]
        rho1[i]=rho[i]
    #ajout de la première étape pour avoir la partie entre R=0 et Rn[0]
    "je teste le rajout de T et P entre 0 et 0.05"
    frac2=np.linspace(0.0,0.0495,100)
    supplen=len(frac2)
    rho02=np.zeros(l+supplen)
    rho2=np.zeros(l+supplen)
    Rn2=np.zeros(len(Rn)+supplen)
    Tcmb2=np.zeros(l+supplen)
    Pn2=np.zeros(len(Pn)+supplen)
    # for i in range(l):
    for i in range(0,supplen):
            rho02[i]=rho0[0]
            rho2[i]=rho1[0]
            Tcmb2[i]=Tcmb[0]
            Rn2[i]=Rnf*frac2[i]**(1/3)
            Pn2[i]=Pn[0]
    for i in range(supplen,l+supplen):
            Rn2[i]=Rn[i-supplen]
            Pn2[i]=Pn[i-supplen]
            Tcmb2[i]=Tcmb[i-supplen]
            rho02[i]=rho0[i-supplen]
            rho2[i]=rho1[i-supplen]
#    print(rho2)
    PCMBfin=Pn2[len(Pn2)-1]
    # Pfinal=np.zeros(l[0],l[1]+supplen)
    rhofin=np.zeros(l+supplen)
    Tfin=np.zeros(l+supplen)
    
    Pfinal= fct.Pressioncore(Rn2,PCMBfin)
    
    Tfinal,rhofinal=fct.T_simpleanalytique(Pn2,Tcmb2,Pfinal,coeff,rho02)
    for i in range(l+supplen):
        Tfin[i]=Tfinal[i]
        rhofin[i]=rhofinal[i]
    return(Tcmb2,Tfin,rho2,rhofin,rho02)
def CalculTmoyen(Fef,Nif,Cof,Vf,Crf,Sif,Of,Px,Tx,Pn,Rn,coeff,step):
    l=len(Fef)
    

    rho0th=[7019,7900,8900,2210,6100,7190,365.45] #on se fait pas trop chier au début avec les interactions
    alphaSi=-0.91
    alphaO=-1.3
    rho0=np.zeros(l)
    for i in range(l):
    
        rhoint=rho0th[0]*Fef[l-1]+rho0th[1]*Nif[l-1]+rho0th[2]*Cof[l-1]+rho0th[4]*Vf[l-1]+rho0th[5]*Crf[l-1]
        rho0[i]=rhoint*np.exp(alphaSi*Sif[l-1])*np.exp(alphaO*Of[l-1])
    Tcmb=np.zeros(l)
    rho1=np.zeros(l)
    
    T,rho=fct.T_simpleanalytique(Px,Tx,Pn,coeff,rho0)
    for j in range(l):
        Tcmb[j]=T[j]
        rho1[j]=rho[j]
    #ajout de la première étape pour avoir la partie entre R=0 et Rn[0]
    #ajout de la première étape pour avoir la partie entre R=0 et Rn[0]
    "je teste le rajout de T et P entre 0 et 0.05"
    frac2=np.linspace(0.0,0.0495,100)
    supplen=len(frac2)
    supplen=len(frac2)
    rho02=np.zeros(l+supplen)
    rho2=np.zeros(l+supplen)
    Rn2=np.zeros(len(Rn)+supplen)
    Tcmb2=np.zeros(l+supplen)
    Pn2=np.zeros(len(Pn)+supplen)
    # for i in range(l):
    for i in range(0,supplen):
            rho02[i]=rho0[0]
            rho2[i]=rho1[0]
            Tcmb2[i]=Tcmb[0]
            Rn2[i]=Rnf*frac2[i]**(1/3)
            Pn2[i]=Pn[0]
    for i in range(supplen,l+supplen):
            Rn2[i]=Rn[i-supplen]
            Pn2[i]=Pn[i-supplen]
            Tcmb2[i]=Tcmb[i-supplen]
            rho02[i]=rho0[i-supplen]
            rho2[i]=rho1[i-supplen]
#    print(rho2)
    PCMBfin=Pn2[len(Pn2)-1]
    # Pfinal=np.zeros(l[0],l[1]+supplen)
    rhofin=np.zeros(l+supplen)
    Tfin=np.zeros(l+supplen)
    
    Pfinal= fct.Pressioncore(Rn2,PCMBfin)
    
    Tfinal,rhofinal=fct.T_simpleanalytique(Pn2,Tcmb2,Pfinal,coeff,rho02)
    for i in range(l+supplen):
        Tfin[i]=Tfinal[i]
        rhofin[i]=rhofinal[i]
    return(Tcmb2,Tfin,rho2,rhofin,rho02)
    
def best_fit(compo,P,F,T,Q, Tmoy,Qmoy,element,ref): #element = str
    size=np.shape(compo)
    indice=0 #indice de comparaison
    for i in range(size[1]):
        if compo[0][i]==element:
            indice=i
    #je fais une liste des rapports -1
    liste=[]
    for i in range(1,size[0]):
        r=np.abs((compo[i][indice]/ref[indice])-1)
        liste.append(r)
    rmin=min(liste)
    i_final=0
    for i in range(len(liste)):
        if liste[i] == rmin:
            i_final=i
    #on récupère tout dans un fichier
    output=[['Pbest','Fbest','Tbest','Qbest','Tmoy best','Qmoy best'],[P[i_final],F[i_final],T[i_final],Q[i_final],Tmoy[i_final],Qmoy[i_final]]]
    compo_fit=[compo[0],compo[i_final+1]]
    return(output,compo_fit)