# -*- coding: utf-8 -*-
"""
Created on Tue Oct  6 10:32:31 2020

@author: vince
"""

"Fit pour un élément donné et pour chaque fc, alpha,Pmax"
import FischerBSEcompo as BSE
import numpy as np
import os
import scipy.special as spe #nécessaire pour la fonction gamma 
import scipy.optimize as opt
import math
import csv
import matplotlib.pyplot as plt
import time
import DataFischer as Fis
import Fonctiondefc as acc
import Fonctionalpha as al
import fonctions as fct
import pandas as pd
"File for sorting"
"The notation evolved during, so it is not necessary the same in the code an paper"
"also I am french, so the name of variable are in french. Deal with it"
fc=np.linspace(0.05,1,20) #fc
alpha=np.linspace(0.1,5,50) #lambda
Facteur=np.linspace(0.05,1,20) #a_p
frac=acc.frac
frac2=np.linspace(0.0,0.0495,100)
Tcmbinit=[]
supplen=len(frac2)
frac3=np.zeros(len(frac)+supplen)
for i in range(supplen):
    frac3[i]=frac2[i]
for i in range(supplen,len(frac3)):
    frac3[i]=frac[i-supplen]
Rn=acc.Rn #initial core radius evolution
Rnf=acc.Rnf
"increasing the size of the radius"
newRn=np.zeros(len(Rn)+supplen)
for i in range(0,supplen):
    newRn[i]=Rnf*frac2[i]**(1/3)
for i in range(supplen,len(Rn)+supplen):
    newRn[i]=Rn[i-supplen]
#Pfinal=fct.Pressioncore(Rn,PCMB)
Maxerreur=0.1
"calcul de rd"
Vmax=(4/3)*np.pi*Rn[len(frac)-1]**3
Vmin=(4/3)*np.pi*Rn[len(frac)-2]**3
DeltaV=Vmax-Vmin
Rmax=((3/4)*DeltaV/np.pi)**(1/3)
"Reference composition "
Ref_bse=[BSE.FeO_pc[0]/100,BSE.SiO2_pc[0]/100,BSE.Al2O3_pc[0]/100,BSE.MgO_pc[0]/100,BSE.CaO_pc[0]/100,BSE.NiO_ppm[0]*1e-6,BSE.CoO_ppm[0]*1e-6,BSE.V2O3_ppm[0]*1e-6,BSE.Cr2O3_ppm[0]*1e-6] 
err_bse=[BSE.FeO_pc[1]/100,BSE.SiO2_pc[1]/100,BSE.Al2O3_pc[1]/100,BSE.MgO_pc[1]/100,BSE.CaO_pc[1]/100,BSE.NiO_ppm[1]*1e-6,BSE.CoO_ppm[1]*1e-6,BSE.V2O3_ppm[1]*1e-6,BSE.Cr2O3_ppm[1]*1e-6]
"prep of outputs: best fit for the set fc/lambda + ap"
P_best=[['Pbest']]
F_best=[['Fact best']]
Tis_best=[['Tstrati']]
Tmoy_best=[['Tmoy']]
Q_best=[['Qbest']]
Qmoy_best=[['Qmoybest']]
Fesil_best=[['FeO']]
Sisil_best=[['SiO2']]
Alsil_best=[['Al2O3']]
Casil_best=[['CaO']]
Mgsil_best=[['MgO']]
Nisil_best=[['Nio']]
Cosil_best=[['Coo']]
Vsil_best=[['V2o3']]
Crsil_best=[['Cr2O3']]
Femet_best=[['Fe']]
Simet_best=[['Si']]
Nimet_best=[['Ni']]
Comet_best=[['Co']]
Omet_best=[['O']]
Vmet_best=[['V']]
Crmet_best=[['Cr']]
Nsol=[['Number of solutions']]
minerr=[['Min error']]
"output for only the solutions close enough to the BSE"
PTfit=[['fc','alpha','Pmax','Fact','Tstrati','Qstrati','Tmoyen','Qmoyen']]
Silicate_fit=[['fc','alpha','Pmax','FeO','SiO2','Al2O3', 'MgO', 'CaO', 'NiO', 'CoO', 'V2O3', 'Cr2O3']]
Metal_fit=[['fc','alpha','Pmax','Fe', 'Ni', 'Co', 'Si', 'O', 'V', 'Cr']]
for i in range(len(alpha)):
    P_best[0].append(alpha[i])
    F_best[0].append(alpha[i])
    Tis_best[0].append(alpha[i])
    Tmoy_best[0].append(alpha[i])
    Q_best[0].append(alpha[i])
    Qmoy_best[0].append(alpha[i])
    Fesil_best[0].append(alpha[i])
    Sisil_best[0].append(alpha[i])
    Alsil_best[0].append(alpha[i])
    Casil_best[0].append(alpha[i])
    Mgsil_best[0].append(alpha[i])
    Nisil_best[0].append(alpha[i])
    Cosil_best[0].append(alpha[i])
    Vsil_best[0].append(alpha[i])
    Crsil_best[0].append(alpha[i])
    Femet_best[0].append(alpha[i])
    Simet_best[0].append(alpha[i])
    Nimet_best[0].append(alpha[i])
    Comet_best[0].append(alpha[i])
    Vmet_best[0].append(alpha[i])
    Crmet_best[0].append(alpha[i])
    Omet_best[0].append(alpha[i])
    Nsol[0].append(alpha[i])
    minerr[0].append(alpha[i])
"loop with i for fc, j for alpha (lambda in the paper)"
tempscompo=0
tempsT1=0
tempsT2=0
debuttot=time.time()
for i in range(len(fc)):
    interP=[fc[i]]
    interF=[fc[i]]
    interTis=[fc[i]]
    interQ=[fc[i]]
    interTmoy=[fc[i]]
    interQmoy=[fc[i]]
    interFesil=[fc[i]]
    interSisil=[fc[i]]
    interAlsil=[fc[i]]
    interMgsil=[fc[i]]
    interCasil=[fc[i]]
    interNisil=[fc[i]]
    interCosil=[fc[i]]
    interVsil=[fc[i]]
    interCrsil=[fc[i]]
    interFemet=[fc[i]]
    interNimet=[fc[i]]
    interComet=[fc[i]]
    interSimet=[fc[i]]
    interOmet=[fc[i]]
    interVmet=[fc[i]]
    interCrmet=[fc[i]]
    interN=[fc[i]]
    interErr=[fc[i]]
    for j in range(len(alpha)):
        
        PCMB,P50,T50,m_sil,m_met,m_noyauacc,m_manteauacc,rhomoymet,rhomoysil=acc.Conditioncalcul(fc[i],frac)
        Pmax=Facteur*PCMB[len(frac)-1]
        PCMB2=np.zeros(len(PCMB)+supplen)
        for k in range(0,supplen):
            PCMB2[k]=PCMB[0]
        for k in range(supplen,len(PCMB)+supplen):
            PCMB2[k]=PCMB[k-supplen] #increasing the list of value to have P between 0 and 0.05 % mE
        Pcmbfin=PCMB[len(frac)-1]
        Pfinal=fct.Pressioncore(Rn,Pcmbfin)
        Pfinal2=fct.Pressioncore(newRn,Pcmbfin)
        
        P,T=al.ParamP(Facteur,PCMB,frac,alpha[j],fc[i]) #Peq, Teq in the text
        g=9.81*frac**(2/3)
        Compomet1=acc.Compomet1
        Compomet2=acc.Compomet2
        Composil1=acc.Composil1
        Composil2=acc.Composil2
        debut=time.time()
        Fef,FeOf,Nif,NiOf,Cof,CoOf,Sif,SiOf,Vf,VOf,Crf,CrOf,Of,AlOf,CaOf,MgOf,Fe,FeO,Ni,NiO,Co,CoO,Si,SiO,V,VO,Cr,CrO,O,AlO,CaO,MgO=al.Compoparam(P,T,Compomet1,Compomet2,Composil1,Composil2,m_sil,m_met,m_manteauacc,m_noyauacc,fc[i],frac)
        fin=time.time()
        tempscompo=tempscompo+(fin-debut)
        "Calcul of T"
        coeff=acc.coeff_norm
        step=100
        debut1=time.time()
        Tis0=[]
        gamma0=1.875
        gammainf=1.305
        beta=gamma0/(gamma0-gammainf)
        K0=128.49198251
        K1=3.66847041
        Tcmb,Tfin,rho1,rhofin,rho0=al.CalculTparam(Fe,Ni,Co,V,Cr,Si,O,P,T,PCMB,Rn,K0,K1,gamma0,gammainf,beta)
        for n in range(len(Facteur)):
            Tis0.append(Tfin[n][len(Tfin[n])-1])
        # print(Tfin)
        fin1=time.time()
        tempsT1=tempsT1+fin1-debut1
        debut2=time.time()
        "old function, here to just extract the density profile after mixing"
        Tcmbmoy,Tfinmoy,rhocmbmoy,rhofinmoy,rho0moy=al.CalculTmoyen(Fef,Nif,Cof,Vf,Crf,Sif,Of,P,T,PCMB,Rn,K0,K1,gamma0,gammainf,beta)  
        fin2=time.time()
        tempsT2=tempsT2+fin2-debut2
        
        "Calcul of Q et Tis"
        
        Qis0=[]
        Tismoy=[]
        Qismoy=[] 
        for k in range(len(Facteur)):
            
            Tis,Qis,Ris=fct.TQcalc(Tfin[k],rhofin[k],rhofinmoy[k],rho0moy[k],newRn,gamma0,gammainf,beta,step)
            Qmoy=Ris*Qis #test to see if we are off
            Tismoy.append(Tis)
            Qis0.append(Qis)
            Qismoy.append(Qmoy)
         


        
        "weight of éléments"
        poids=[0.142,0.025,0.03,0.039,0.029,0.376,0.228,0.072,0.059]
        "Compo finals"
        Compofinsil=[['FeO','SiO2','Al2O3','MgO','CaO','NiO','CoO','V2O3','Cr2O3']]
        Compofinmet=[['Fe','Ni','Co','Si','O','V','Cr']]
        for m in range(len(Facteur)):
            cfin=[FeOf[m][len(frac)-1],SiOf[m][len(frac)-1],AlOf[m][len(frac)-1],MgOf[m][len(frac)-1],CaOf[m][len(frac)-1],NiOf[m][len(frac)-1],CoOf[m][len(frac)-1],VOf[m][len(frac)-1],CrOf[m][len(frac)-1]]
            cfinmet=[Fef[m][len(frac)-1],Nif[m][len(frac)-1],Cof[m][len(frac)-1],Sif[m][len(frac)-1],Of[m][len(frac)-1],Vf[m][len(frac)-1],Crf[m][len(frac)-1]]
            Compofinsil.append(cfin)
            Compofinmet.append(cfinmet)
        output_best,composil_best,compomet_best,error,output_fit,n_sol,composil_fit,compomet_fit=al.best_fitall(Compofinsil,Compofinmet,Pmax,Facteur,Tis0,Qis0,Tismoy,Qismoy,Ref_bse,Maxerreur,poids) # sorting out the compositions
        #on remplit d'abord les fits
        if output_fit[1][0] !='No solutions':
            
            for k in range(1,len(output_fit)):
                linePT=[fc[i],alpha[j]]
                linesil=[fc[i],alpha[j],output_fit[k][0],output_fit[k][1]]
                linemet=[fc[i],alpha[j],output_fit[k][0],output_fit[k][1]]
                for q in range(len(output_fit[0])):
                    data=output_fit[k][q]
                    linePT.append(data)
                PTfit.append(linePT)
                for r in range(len(composil_fit[0])):
                    Xsil=composil_fit[k][r]
                    linesil.append(Xsil)
                Silicate_fit.append(linesil)
                for m in range(len(compomet_fit[0])):
                    Xmet=compomet_fit[k][m]
                    linemet.append(Xmet)
                Metal_fit.append(linemet)
                
            
        
        interP.append(output_best[1][0]*1e-9)
        interF.append(output_best[1][1])
        interTis.append(output_best[1][2])
        interQ.append(output_best[1][3])
        interTmoy.append(output_best[1][4])
        interQmoy.append(output_best[1][5])
        interFesil.append(composil_best[1][0])
        interSisil.append(composil_best[1][1])
        interAlsil.append(composil_best[1][2])
        interMgsil.append(composil_best[1][3])
        interCasil.append(composil_best[1][4])
        interNisil.append(composil_best[1][5])
        interCosil.append(composil_best[1][6])
        interVsil.append(composil_best[1][7])
        interCrsil.append(composil_best[1][8])
        interFemet.append(compomet_best[1][0])
        interNimet.append(compomet_best[1][1])
        interComet.append(compomet_best[1][2])
        interSimet.append(compomet_best[1][3])
        interOmet.append(compomet_best[1][4])
        interVmet.append(compomet_best[1][5])
        interCrmet.append(compomet_best[1][6])
        interN.append(n_sol[1])
        interErr.append(error[1])

    P_best.append(interP)
    F_best.append(interF)
    Tis_best.append(interTis)
    Tmoy_best.append(interTmoy)
    Q_best.append(interQ)
    Qmoy_best.append(interQmoy)
    Fesil_best.append(interFesil)
    Sisil_best.append(interSisil)
    Alsil_best.append(interAlsil)
    Mgsil_best.append(interMgsil)
    Casil_best.append(interCasil)
    Nisil_best.append(interNisil)
    Cosil_best.append(interCosil)
    Vsil_best.append(interVsil)
    Crsil_best.append(interCrsil)
    Femet_best.append(interFemet)
    Nimet_best.append(interNimet)
    Comet_best.append(interComet)
    Simet_best.append(interSimet)
    Omet_best.append(interOmet)
    Vmet_best.append(interVmet)
    Crmet_best.append(interCrmet)
    Nsol.append(interN)
    minerr.append(interErr)
"Export of data: closest composition for fc/lambda doublet"
FeOb=pd.DataFrame(Fesil_best)
FeOb.to_csv('XX-1 Silicate- FeO best fit.csv',index=False)   
SiOb=pd.DataFrame(Sisil_best)
SiOb.to_csv('XX-2 Silicate- SiO best fit.csv',index=False) 
AlOb=pd.DataFrame(Alsil_best)
AlOb.to_csv('XX-3 Silicate- AlO best fit.csv',index=False)  
MgOb=pd.DataFrame(Mgsil_best)
MgOb.to_csv('XX-4 Silicate- MgO best fit.csv',index=False) 
CaOb=pd.DataFrame(Casil_best)
CaOb.to_csv('XX-5 Silicate- CaO best fit.csv',index=False) 
NiOb=pd.DataFrame(Nisil_best)
NiOb.to_csv('XX-6 Silicate- NiO best fit.csv',index=False) 
CoOb=pd.DataFrame(Cosil_best)
CoOb.to_csv('XX-7 Silicate- CoO best fit.csv',index=False) 
VOb=pd.DataFrame(Vsil_best)
VOb.to_csv('XX-8 Silicate- VO best fit.csv',index=False)
CrOb=pd.DataFrame(Crsil_best)
CrOb.to_csv('XX-9 Silicate- CrO best fit.csv',index=False)  
Feb=pd.DataFrame(Femet_best)
Feb.to_csv('X-1 Metal -Fe best fit.csv',index=False)  
Nib=pd.DataFrame(Nimet_best)
Nib.to_csv('X-2 Metal -Ni best fit.csv',index=False)
Cob=pd.DataFrame(Comet_best)
Cob.to_csv('X-3 Metal -Co best fit.csv',index=False)
Sib=pd.DataFrame(Simet_best)
Sib.to_csv('X-4 Metal -Si best fit.csv',index=False)
Ob=pd.DataFrame(Omet_best)
Ob.to_csv('X-5 Metal -O best fit.csv',index=False)
Crb=pd.DataFrame(Crmet_best)
Crb.to_csv('X-6 Metal -Cr best fit.csv',index=False)
Vb=pd.DataFrame(Vmet_best)
Vb.to_csv('X-7 Metal -V best fit.csv',index=False)           
Pfit=pd.DataFrame(P_best)
Pfit.to_csv('YY- FeO best fit Pressure.csv',index=False)
Ffit=pd.DataFrame(F_best)
Ffit.to_csv('YY- FeO best fit Fact.csv',index=False)
Tfit=pd.DataFrame(Tis_best)
Tfit.to_csv('YY- FeO best fit T strati.csv',index=False)
Qfit=pd.DataFrame(Q_best)
Qfit.to_csv('YY- FeO best fit Q strati.csv',index=False)
Tmfit=pd.DataFrame(Tmoy_best)
Tmfit.to_csv('YY- FeO best fit T moyen.csv',index=False)
Qmfit=pd.DataFrame(Qmoy_best)
Qmfit.to_csv('YY- FeO best fit Q moy.csv',index=False)
"Export of the solutions that match the maximum error for the BSE"
Metal_fit1=pd.DataFrame(Metal_fit)
Metal_fit1.to_csv('AA-3-Compo fittée Metal.csv',index=False)
Sil_fit1=pd.DataFrame(Silicate_fit)
Sil_fit1.to_csv('AA-2-Compo fitté Silicate.csv',index=False)
PTrange=pd.DataFrame(PTfit)
PTrange.to_csv('AA-1-Data T et Q fitté.csv',index=False)
Nsol_fit=pd.DataFrame(Nsol)
Nsol_fit.to_csv('AA-4-Nombre de solutions.csv',index=False)
minerr_fit=pd.DataFrame(minerr)
minerr_fit.to_csv('AA-5-Minimum Erreurmoyenne.csv',index=False)
fintot=time.time()
tempstotal=fintot-debuttot
print('Time composition '+str(round(tempscompo/60,2))+' minutes')
print('Time T1='+str(round(tempsT1/60,2))+' minutes')
print('Time T2='+str(round(tempsT2/60,2))+' minutes')
print('Time Total='+str(round(tempstotal/60,2))+' minutes')

