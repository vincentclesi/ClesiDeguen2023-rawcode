# -*- coding: utf-8 -*-
"""
Created on Wed Sep 16 14:15:22 2020

@author: Vincent
"""
import numpy as np
import csv
import matplotlib as plt
import scipy.optimize as opt
"Fichier recap des fonctions nécessaires pour calculer Tcmb, Tfinale, Tcmb isentrope, rhofinale"
"+ Delta Gravi potentielle"

"Basic data used in most functions"
Rnf=3470000 #•Rayon noyau final
gamma0 = 1.735; #valeur de gruneisen donnée par anderson & Ahrens (1994)
alphaT=11e-6 #coeff de dilatation thermique en K-1 
Cpm = 1000;# Specific heat métal in J/kg.K
"Fonctions de base: Pression et densité"
def Pressioncore(R,Pcmb): #Core pressure. P in Pa, R in m
    P=364e9+((Pcmb-364e9)/Rnf**2)*R**2
    return(P)
# def rho_poly(P,coeff):
#     ratio_poly=np.zeros(len(P))
#     for i in range(len(P)):
#         ratio_poly[i]=coeff[2]*1+coeff[1]*(P[i]*1e-9)+ coeff[0]*(P[i]*1e-9)**2
        
#     return(ratio_poly)
# def rhofinal(Pn,Pfinal,rho_init,coeffrho,rho0):
#     rhofinal=np.zeros(len(Pfinal))
#     for i in range(len(Pfinal)):
#     #rhofinal[i]=rho_init[i]*(coeffrho[0]*((Pfinal[i]-Pn[i])*1e-9)**2+coeffrho[1]*((Pfinal[i]-Pn[i])*1e-9))
#         rhofinal[i]=rho_init[i]+ rho0[i]*coeffrho[1]*(Pfinal[i]*1e-9-Pn[i]*1e-9)+ rho0[i]*coeffrho[0]*((Pfinal[i]*1e-9)**2-(Pn[i]*1e-9)**2)
#     return(rhofinal)
"ON prend les temperatures"
"Fonction température: analytique pour la TCMB, "
"Analytical compresive heat: Px Tx = starting P T. K1= K'. The rest is transparent"
def T_simpleanalytique(Px,Tx,Pn,K0,K1,rho0,gamma0,gammainf,beta):
    T_out=np.zeros(len(Pn))
    rho_out= np.zeros(len(Pn))
    Px=Px*1e-9
    Pn=Pn*1e-9
    for i in range(len(Pn)):
        haut=K1*Pn[i]+K0
        bas=K1*Px[i]+K0
        I1=(haut/bas)**(gammainf/K1)
        # print(I1)
        
        facteur=(gamma0-gammainf)*(K0**(beta/K1))/beta
        gauche=1/((K1*Px[i]+K0)**(beta/K1))
        droite=1/((K1*Pn[i]+K0)**(beta/K1))
        
        I2= facteur*(gauche-droite)
        T_out[i]=Tx[i]*I1*np.exp(I2)
        
        ratio=(1+ (K1/K0)*Pn[i])**(1/K1)
        rho_out[i]=rho0[i]*ratio
    return(T_out,rho_out) # out give the T and density profile after compression
"function with dissipation"
def T_dissipation(Px,Tx,Pn,K0,K1,rho0,gamma0,gammainf,beta,rhosil,epsilon,step):
    T_cmb=np.zeros(len(Pn))
    rho_init= np.zeros(len(Pn))
    Px=Px*1e-9
    Pn=Pn*1e-9
    nstep=int(step)-1
    for i in range(len(Pn)):
        I=0
        rho_eq=rho0[i]*(1+(K1/K0)*Px[i])**(1/K1)
        rho_f=rho0[i]*(1+(K1/K0)*Pn[i])**(1/K1)
        rho_init[i]=rho_f
        facteurglobal=((rho_f/rho_eq)**(gammainf))*np.exp(((gamma0-gammainf)/beta)*((rho0[i]/rho_eq)**beta-(rho0[i]/rho_f)**beta))
        rhoint=np.linspace(rho_eq,rho_f,nstep)
        Pint=np.linspace(Px[i],Pn[i],nstep)
        for j in range(nstep-1):
            f1=(-1/rhoint[j] + 1/rhosil[i])*((rhoint[j]/rho_eq)**(gammainf))*np.exp(((gamma0-gammainf)/beta)*((rho0[i]/rho_eq)**beta-(rho0[i]/rhoint[j])**beta))
            f2=(-1/rhoint[j+1] + 1/rhosil[i])*((rhoint[j+1]/rho_eq)**(gammainf))*np.exp(((gamma0-gammainf)/beta)*((rho0[i]/rho_eq)**beta-(rho0[i]/rhoint[j+1])**beta))
            I= I + (f1+f2)*(Pint[j+1]-Pint[j])/2
        T_cmb[i]=facteurglobal*(Tx[i]+ epsilon*I*1e9/Cpm)
        
    return(T_cmb,rho_init)

"isnetropic temperature"
def TQcalc(Tinit,rhostrati,rhomoyen,rho0moyen,Rn,gamma0,gammainf,beta,step):
    "calcul of Q using rhostrati"
    Q=0 #initiation de l'intégrale
    Cpm=1000
    nstep=int(step)-1
    for i in range(len(Tinit)-1):
        Tinter=np.linspace(Tinit[i],Tinit[i+1],nstep) #T interpolée linéairement entre 2 points
        rhointer=np.linspace(rhostrati[i],rhostrati[i+1],nstep) #idem rho
        Rinter=np.linspace(Rn[i],Rn[i+1],nstep)
        Qinter=0
        for j in range(nstep-1):
            f1=4*Cpm*np.pi*Tinter[j]*rhointer[j]*Rinter[j]**2
            f2=4*Cpm*np.pi*Tinter[j+1]*rhointer[j+1]*Rinter[j+1]**2
            Qinter=Qinter+(f1+f2)*(Rinter[j+1]-Rinter[j])/2
        Q=Q+Qinter
    
    "Calcul of t_cmb isentropic for rho mixed = rhomoyen"
    I=0 #intégrale de 0 à Rcore de 4pi*((rho/rho_cmb)^gamma)*rho*r**2 dr
    rho_cmb=rhomoyen[len(rhomoyen)-1]
    
    
    for i in range(len(Tinit)-1):
        # Tinter=np.linspace(Tinit[i],Tinit[i+1],nstep) #T interpolée linéairement entre 2 points
        rhointer=np.linspace(rhomoyen[i],rhomoyen[i+1],nstep) #idem rho
        Rinter=np.linspace(Rn[i],Rn[i+1],nstep)
        Iinter=0
        for j in range(nstep-1):
            fact1=4*Cpm*np.pi*rhointer[j]*(Rinter[j]**2)*((rhointer[j]/rho_cmb)**gammainf)*np.exp(((gamma0-gammainf)/beta)*((rho0moyen[i]/rho_cmb)**beta - (rho0moyen[i]/rhointer[j])**beta))
            fact2=4*Cpm*np.pi*rhointer[j]*(Rinter[j]**2)*((rhointer[j+1]/rho_cmb)**gammainf)*np.exp(((gamma0-gammainf)/beta)*((rho0moyen[i]/rho_cmb)**beta - (rho0moyen[i]/rhointer[j+1])**beta))
            Iinter=Iinter+(fact1+fact2)*(Rinter[j+1]-Rinter[j])/2
        I=I+ Iinter
        # print(I)
    Tcmb_is=Q/I
    "Test if we get the same Q when recalculating the heat content"
    Tisentrope=Tcmb_is*((rhomoyen/rho_cmb)**gammainf)*np.exp(((gamma0-gammainf)/beta)*((rho0moyen/rho_cmb)**beta - (rho0moyen/rhomoyen)**beta))
    Q2=0
    for i in range(len(Tisentrope)-1):
        Tinter=np.linspace(Tisentrope[i],Tisentrope[i+1],nstep)
        rhointer=np.linspace(rhomoyen[i],rhomoyen[i+1],nstep)
        Rinter=np.linspace(Rn[i],Rn[i+1],nstep)
        Q2inter=0
        for j in range(nstep-1):
            test1=4*np.pi*rhointer[j]*Tinter[j]*Rinter[j]**2
            test2=4*np.pi*rhointer[j+1]*Tinter[j+1]*Rinter[j+1]**2
            Q2inter=Q2inter+(test1+test2)*(Rinter[j+1]-Rinter[j])/2
        Q2=Q2+Q2inter
    ratio=Q2/Q
    return(Tcmb_is,Q,ratio)

def profilisentrope(Tfin,rhofin,gamma):
    Tcmb=Tfin[len(Tfin)-1]
    rhocmb=rhofin[len(rhofin)-1]
    Tisentrope=Tcmb*(rhofin/rhocmb)**gamma
    return(Tisentrope)

def CMBisentrope(rho,gamma,R,step): #fonction d'intégration
    rho_cmb=rho[len(rho)-1]
    I=0 
    nstep=int(step)-1
    for i in range(len(rho)-1):
        rho1=np.linspace(rho[i],rho[i+1],nstep)
        R1=np.linspace(R[i],R[i+1],nstep)
        for j in range(nstep-1):
            fact1=(R1[j]**2)*(rho1[j]/rho_cmb)**(gamma+1)
            fact2=(R1[j+1]**2)*(rho1[j+1]/rho_cmb)**(gamma+1)
            I=I+(fact1+fact2)*(R1[j+1]-R1[j])/2
    I_totale=4*np.pi*rho_cmb*Cpm*I
    return(I_totale)


"Calcul des delta E gravi"
"D'abord g = fonction de R"
"on fait en numérique comme ça on s'emmerde pas"
def masse(Rn,rho,step):
    m=np.zeros(len(Rn))
    nstep=int(step-1)
    for i in range(len(Rn)-1):
        r1=np.linspace(Rn[i],Rn[i+1],nstep)
        rho1=np.linspace(rho[i],rho[i+1],nstep)
        I=0
        for j in range(nstep-1):
            m1=rho1[j]*r1[j]**2
            m2=rho1[j+1]*r1[j+1]**2
            I=I+(m1+m2)*(r1[j+1]-r1[j])/2
        m[i+1]=m[i]+4*np.pi*I
    return(m) #m=f(Rn)
def gravi(Rn,rho,step):
    G=6.67430*1e-11
    g=np.zeros(len(Rn))
    nstep=int(step-1)
    for i in range(1,len(g)):
        r1=np.linspace(0,Rn[i],nstep)
        rho1=np.linspace(rho[0],rho[i],nstep)
        I=0
        for j in range(len(r1)-1):
            poly1=(rho1[j])*(r1[j])**2
            poly2=(rho1[j+1])*(r1[j+1])**2
            I=I + (poly1+poly2)*(r1[j+1]-r1[j])/2
        g[i]=4*np.pi*G*I/(Rn[i]**2)
    return(g)
"calcul de De/dr"
def dEpot(g,rho,R):
    Ep=np.zeros(len(g))
    for i in range(len(g)):
        Ep[i]=4*np.pi*g[i]*rho[i]*R[i]
    return(Ep)
'intégration'
def Epotentielle(Rn,rho,step): 
    E=0
    nstep=int(step)-1
    Itot=0 #integration totale
    for i in range(len(Rn)-1):
        rho1=np.linspace(rho[i],rho[i+1],nstep) #multiplication des points intermédiare
        r1=np.linspace(Rn[i],Rn[i+1],nstep)
        g1=gravi(r1,rho1,step)
        I=0
        for j in range(nstep-1):
            func1= 4*np.pi*rho1[j]*g1[j]*r1[j]**3
            func2= 4*np.pi*rho1[j+1]*g1[j+1]*r1[j+1]**3
            I = I + (func1+func2)*(r1[j+1]-r1[j])/2
        Itot=Itot+I
    E=Itot
    return(E)
"COmpositions"
def logKd(param,P,T):
    Kd=np.zeros(len(P))
    for i in range(len(P)):
        Kd[i]=param[0]+param[1]/T[i]+param[2]*(P[i]*1e-9)/T[i]
    return(Kd)
"Parmaetrisation"



def PeqWborne(fact,frac,k,fc,Pn):
    Pmax=fact*Pn
    Peq=Pmax*((1-np.exp(-(frac/fc)**k))/(1-np.exp(-(1/fc)**k)))
    return(Peq)

