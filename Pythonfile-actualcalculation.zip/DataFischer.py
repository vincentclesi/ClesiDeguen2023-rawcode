# -*- coding: utf-8 -*-
"""
Created on Thu Jun 11 15:46:18 2020

@author: vince
Data de Fischer pour refaire le modèle
"""
"Tables of compo sous la forme Reduced/Oxidized in % wtoxide"
SiO2=[0.5141, 0.4219]
MgO=[0.375, 0.294]
FeO=[0.0224, 0.2113]
AlO15=[0.0462, 0.0363]
CaO = [0.0375, 0.0295]
NiO= [0.0000101, 0.000174]
CoO=[0.0000051, 0.000083]
VO15=[0.000203, 0.000164]
CrO=[0.0045, 0.00617]
"same for metal in %wt"
Fe=[0.911, 0.8907]
Ni=[0.0555, 0.100]
Co=[0.0026, 0.0044]
O=[0.0004, 0.004]
Si=[0.024, 0.000205]
V=[0.00000924, 0.000000775]
Cr=[0.0061, 0.000870]
"Metal fraction"
Fracmetal=[0.313, 0.165]
# Cut=0.75
"Fischer et al. values"
"Format log10Kd= a +b/T+cP/T"
KdNi=[0.46,2700,-61]
KdCo=[0.36,1500,-33]
KdV=[-0.3,-5400,19]
KdCr=[0,-2900,9]
KdSi=[1.3,-13500,0]
KdO=[0.6,-3800,22]
"list of rho0"
rhoinit=[7019,7900,8900,2550,6100,7190,1275]

