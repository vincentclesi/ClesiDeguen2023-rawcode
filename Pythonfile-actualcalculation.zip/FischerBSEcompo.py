# -*- coding: utf-8 -*-
"""
Created on Fri Oct  2 11:47:01 2020

@author: Vincent
"""

"Compo of BSE McDonough adapted to Fischer number of element"
"Il nous faut les compositions en % d'élément, en % d'oxyde, et les ratios importants"
"Normaliser par rapport à notre composition (i.e. on néglige pas mal d'éléments)"

"BSE Fischer"
"list format: [value,error]"
FeO_pc=[8.10,0.81] #en % wt
SiO2_pc=[45.18,4.52]
Al2O3_pc=[4.4658,0.45]
MgO_pc=[38.0276,3.80]
CaO_pc=[3.5607,0.36]
NiO_ppm=[2509,251] #☺ in ppm
CoO_ppm=[134,13]
V2O3_ppm=[121,18]
Cr2O3_ppm=[3859,579]
fo2_iw=[-2.04,0.5] #no unit
NiCo= [18.68,2] # ratio Ni/Co
CrV=[31.80,3.2] # ratio Cr/V
