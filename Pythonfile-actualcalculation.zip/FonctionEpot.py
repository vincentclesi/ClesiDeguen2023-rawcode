# -*- coding: utf-8 -*-
"""
Created on Wed Jan 26 09:47:10 2022

@author: vince
"""
"Fonction que j'utilise pour calculer l'energie potentielle"
import numpy as np
G=6.67430*1e-11
def newEpot2(Rn,rho,step): # Rn= 100 points entre 0 et 5% du rayon final, puis 20 points entre 5 et 100% du rayon final
    nstep=int(step-1)
    "calcul de g"
    g=np.zeros(len(Rn))
    m=np.zeros(len(Rn))
    # m(r) = 4pi*integrale(de 0 à r) rho(r')*r'**2 dr'
    for i in range(len(Rn)-1):
        I1=0
        r1=np.linspace(Rn[i],Rn[i+1],nstep)
        rho1=np.linspace(rho[i],rho[i+1],nstep)
        for j in range(nstep-1):
            x1=rho1[j]*r1[j]**2
            x2=rho1[j+1]*r1[j+1]**2
            I1=I1+(x1+x2)*(r1[j+1]-r1[j])/2 #I1 = masse entre rayon Ri et Ri+1 par intégration
        m[i+1]=4*np.pi*I1 +m[i] #la masse est la masse entre Ri et Ri+1 + la masse jusqu'à i-1
    for i in range(1,len(g)): # à R=0, g=0
        g[i]=G*m[i]/(Rn[i]**2) 
        # print(g[i])
    
    "calcul de Epot"
    Epot=0
    for i in range(len(Rn)-1):
        g1=np.linspace(g[i],g[i+1],nstep)
        r1=np.linspace(Rn[i],Rn[i+1],nstep)
        rho1=np.linspace(rho[i],rho[i+1],nstep)
        for j in range(nstep-1):
            y1=4*np.pi*g1[j]*(r1[j]**3)*rho1[j] #integrale en utilisant la formule de Flasar
            y2=4*np.pi*g1[j+1]*(r1[j+1]**3)*rho1[j+1]
            Epot=Epot+(y1+y2)*(r1[j+1]-r1[j])/2
            # print(Epot)
    return(Epot,g)