# -*- coding: utf-8 -*-
"""
Created on Tue Oct  6 09:40:46 2020

@author: vince
"""

"Fichier des fonctions présentes dans Fischer cut"
import numpy as np
import os
import scipy.special as spe #nécessaire pour la fonction gamma 
import scipy.optimize as opt
import math
import csv
import matplotlib.pyplot as plt
import time
import DataFischer as Fis
"list of parametres used"
G=6.6742*1e-11 #en N.m2/kg
g_constant= 9.81; 
rho0k=7874
rho_sil = 3300 #Constante en kg/m3
expo =[1,2.5,5,10,25,50,100,250,500,750,1000]#multiplieur pour le rayon en m plus tard
gamma0 = 1.735; #valeur de gruneisen donnée par anderson & Ahrens (1994)
K0 = 109.7*1e9 #en Pa
dK=4.66 #K' de Anderson et ahrens sans unité
Cpm = 1000;# Chaleur spécifiqque métal en J/kg.K, même valeur que dans le rapport
Cps = 500; # Cahleur spécifique silicate en J/kg.K, même valeur que dans le rapport
mu_sil = 1e18; # viscosité perovskite (Yamazaki 2001)
lambda_sil = 0.1 # en W.m-1.K.-1, conductivité thermique des silicates (oredre de grandeur)
lambda_met= 100 # en W.m-1.K-1, ordre de grandeur de la condutivité pour le métal
D_sil= 1e-6; #diffusivité en m2/s dans les silicates
Rd=100e3 #Rd en m
v_stokes= (2/9)*(rho0k-rho_sil)*g_constant*(Rd**2)/mu_sil
Pe = Rd*v_stokes/D_sil;
a = 1;  # valeur arbitraire de constante fois10^-9 pour le transfert en GPa
alpha=11e-6 #coeff de dilatation thermique en K-1 (pris à 25° pour l'acier)
"molar masse in g par mol. multiplied by 1e-3 pour les kg/mol"
MFe=55.845*1e-3 #transformé en kg/mol
MNi=58.6934*1e-3
MCo=58.9332*1e-3
MO=15.999*1e-3
MSi=28.0855*1e-3
MMg=24.305*1e-3
MAl=26.9815*1e-3
MV=50.9415*1e-3
MCr=51.9961*1e-3
MCa=40.078*1e-3
#Tm = 1940 # température liquidus en surface
"Rayon de la planète en fonction de laccretion"
RTf = 6370000 #final radius earth in m
Rnf=3470000 #•core radius in m
MT=5.972e24 #masse earth in kilos

frac= np.linspace(0.05,1,20) ;


"Test masse/rayon"

m_acc=np.zeros(len(frac))
R_acc=np.zeros(len(frac))
rhomoy=np.zeros(len(frac))
Rn=np.zeros(len(frac))
g_surf=np.zeros(len(frac))
for i in range(len(frac)):
     m_acc[i]=frac[i]*MT
     R_acc[i] = RTf*(frac[i]**(1/3))
     rhomoy[i] = m_acc[i]/((4/3)*np.pi*R_acc[i]**(3))
     Rn[i]=Rnf*frac[i]**(1/3)
     Vn=(4/3)*np.pi*Rn[i]**3
     Vm=(4/3)*np.pi*R_acc[i]**(3)-(4/3)*np.pi*Rn[i]**3
     g_surf[i]=G*m_acc[i]/(R_acc[i]**2)

    
"Def of conditions we need based on the value of fc"
def Conditioncalcul(f,frac):
    cut=f
    rhomoymet=np.zeros(len(frac))
    rhomoysil=np.zeros(len(frac))
    PCMB=np.zeros(len(frac))
    P50=np.zeros(len(frac))
    T50=np.zeros(len(frac))
    m_noyauacc=np.zeros(len(frac)) #masse cumulée de noyau
    m_met=np.zeros(len(frac)) #masse métal qui est ajoutée au temps x
    m_manteauacc=np.zeros(len(frac)) #masse cumulée du manteau
    m_sil=np.zeros(len(frac)) #masse silicate accrétée au temps x
    m_sil[0]=(1-Fis.Fracmetal[0])*m_acc[0]
    m_met[0]=(Fis.Fracmetal[0])*m_acc[0]
    m_manteauacc[0]=m_sil[0]
    m_noyauacc[0]=m_met[0]
    Vn=(4/3)*np.pi*Rn[0]**3
    Vm=(4/3)*np.pi*R_acc[0]**(3)-(4/3)*np.pi*Rn[0]**3
    rhomoymet[0]=m_noyauacc[0]/Vn
    rhomoysil[0]=m_manteauacc[0]/Vm 
    fact=(4/3)*np.pi*G*rhomoysil[0]
    PCMB[0]=fact*((0.5*rhomoysil[0]*(R_acc[0]**2-Rn[0]**2))+ Rn[0]**3*(rhomoymet[0]-rhomoysil[0])*(1/(Rn[0])-1/R_acc[0]))
    R50= (R_acc[0]-Rn[0])/2 + Rn[0]
    P50[0]=fact*((0.5*rhomoysil[0]*(R_acc[0]**2-R50**2))+ Rn[0]**3*(rhomoymet[0]-rhomoysil[0])*(1/(R50)-1/R_acc[0]))
    T50[0]= 1940*(P50[0]*1e-9/(29) +1)**(1/1.9)
    for i in range(1,len(frac),1):
        if frac[i] < cut:
            met=Fis.Fracmetal[0]
            m_met[i]=(m_acc[i]-m_acc[i-1])*met
            m_sil[i]=(m_acc[i]-m_acc[i-1])*(1-met)
            m_noyauacc[i]= m_noyauacc[i-1]+m_met[i]
            m_manteauacc[i]= m_manteauacc[i-1]+m_sil[i]
            Vn=(4/3)*np.pi*Rn[i]**3
            Vm=(4/3)*np.pi*R_acc[i]**(3)-(4/3)*np.pi*Rn[i]**3
            rhomoymet[i]=m_noyauacc[i]/Vn
            rhomoysil[i]=m_manteauacc[i]/Vm 
            fact=(4/3)*np.pi*G*rhomoysil[i]
            PCMB[i]=fact*((0.5*rhomoysil[i]*(R_acc[i]**2-Rn[i]**2))+ Rn[i]**3*(rhomoymet[i]-rhomoysil[i])*(1/(Rn[i])-1/R_acc[i]))
            R50= (R_acc[i]-Rn[i])/2 + Rn[i]
            P50[i]=fact*((0.5*rhomoysil[i]*(R_acc[i]**2-R50**2))+ Rn[i]**3*(rhomoymet[i]-rhomoysil[i])*(1/(R50)-1/R_acc[i]))
            T50[i]= 1940*(P50[i]*1e-9/(29) +1)**(1/1.9)
        else:
            met=Fis.Fracmetal[1]
            m_met[i]=(m_acc[i]-m_acc[i-1])*met
            m_sil[i]=(m_acc[i]-m_acc[i-1])*(1-met)
            m_noyauacc[i]= m_noyauacc[i-1]+m_met[i]
            m_manteauacc[i]= m_manteauacc[i-1]+m_sil[i]
            Vn=(4/3)*np.pi*Rn[i]**3
            Vm=(4/3)*np.pi*R_acc[i]**(3)-(4/3)*np.pi*Rn[i]**3
            rhomoymet[i]=m_noyauacc[i]/Vn
            rhomoysil[i]=m_manteauacc[i]/Vm 
            fact=(4/3)*np.pi*G*rhomoysil[i]
            PCMB[i]=fact*((0.5*rhomoysil[i]*(R_acc[i]**2-Rn[i]**2))+ Rn[i]**3*(rhomoymet[i]-rhomoysil[i])*(1/(Rn[i])-1/R_acc[i]))
            R50= (R_acc[i]-Rn[i])/2 + Rn[i]
            P50[i]=fact*((0.5*rhomoysil[i]*(R_acc[i]**2-R50**2))+ Rn[i]**3*(rhomoymet[i]-rhomoysil[i])*(1/(R50)-1/R_acc[i]))
            T50[i]= 1940*(P50[i]*1e-9/(29) +1)**(1/1.9)
    return(PCMB,P50,T50,m_sil,m_met,m_noyauacc,m_manteauacc,rhomoymet,rhomoysil)
"Déf of composition: "
" silicates in % oxydes "
Compomet1=[Fis.Fe[0],Fis.Ni[0],Fis.Co[0],Fis.Si[0],Fis.V[0],Fis.Cr[0],Fis.O[0]]
Compomet2=[Fis.Fe[1],Fis.Ni[1],Fis.Co[1],Fis.Si[1],Fis.V[1],Fis.Cr[1],Fis.O[1]]
Composil1=[Fis.FeO[0],Fis.NiO[0],Fis.CoO[0],Fis.SiO2[0],Fis.VO15[0],Fis.CrO[0],Fis.AlO15[0],Fis.CaO[0],Fis.MgO[0]]
Composil2=[Fis.FeO[1],Fis.NiO[1],Fis.CoO[1],Fis.SiO2[1],Fis.VO15[1],Fis.CrO[1],Fis.AlO15[1],Fis.CaO[1],Fis.MgO[1]]
massemolsil=[(MFe+MO),(MNi+MO),(MCo+MO),(MSi+2*MO),(MV+1.5*MO),(MCr+MO), (MAl+1.5*MO), (MCa+MO), (MMg+MO)]
massemolmet=[MFe,MNi,MCo,MSi,MV,MCr,MO]

Compomet=[Compomet1,Compomet2]
Composil=[Composil1,Composil2]

"Rubie 2011 formalism a' =a1"
"function when we have the solution"
def molfinale(x1,KdNi,KdSi,KdO,a,b,c,d,x,y,z,u,m,n): #x1 must have the right value
    y1=x1*(y+b)/((x+a-x1)*KdNi+x1)
    a1=x+a-x1
    b1=y+b-y1
    alpha=z+d
    gamma=a1+b1+x+y+3*z+c-x1-y1+d
    sigma=x1+y1+u+m+n
    a_si=3*x1*x1 - KdSi*a1*a1
    b_si=-(gamma*x1*x1+ 3*alpha*x1*x1 +KdSi*sigma*a1*a1)
    c_si=alpha*gamma*x1*x1
    delta_si= b_si*b_si -4*a_si*c_si
    sol1=(-b_si - np.sqrt(delta_si))/(2*a_si)
    sol2=(-b_si + np.sqrt(delta_si))/(2*a_si)
    if sol1<0:
        z1=sol2
    else:
        z1=sol1
    c1=x+y+2*z+c-x1-y1-2*z1
    d1=z+d-z1
    Xfeo=x1/(x1+y1+z1+u+m+n)
    Xmw=1.148*Xfeo + 1.319*Xfeo*Xfeo
    sigmamet=a1+b1+c1+d1
    Kdcalc=(a1*c1)/(Xmw*sigmamet*sigmamet)
    DeltaK=Kdcalc-KdO
    return(DeltaK,a1,b1,c1,d1,x1,y1,z1)
def Compoimpact(m_sil,m_met,composil,compomet,KdNi,KdCo,KdSi,KdV,KdCr,KdO):
    moltotsil=np.zeros(len(composil))
    moltotmet=np.zeros(len(compomet))
    for i in range(len(composil)):
        moltotsil[i]=(m_sil*composil[i])/massemolsil[i]
    for j in range(len(Compomet1)):
        moltotmet[j]=(m_met*compomet[j])/massemolmet[j]
    #rubie 2011 formalism
    a=moltotmet[0]
    b=moltotmet[1]
    c=moltotmet[6]
    d=moltotmet[3]
    x=moltotsil[0]
    y=moltotsil[1]
    z=moltotsil[3]
    u=moltotsil[6]
    m=moltotsil[7]
    n=moltotsil[8]
    def Fesolve(x1): #internal function for solving x1
        y1=x1*(y+b)/((x+a-x1)*KdNi+x1)
        a1=x+a-x1
        b1=y+b-y1
        alpha=z+d
        gamma=a1+b1+x+y +3*z+c-x1-y1+d
        sigma=x1+y1+u+m+n
        a_si=3*x1*x1 - KdSi*a1*a1
        b_si=-(gamma*x1*x1+ 3*alpha*x1*x1 +KdSi*sigma*a1*a1)
        c_si=alpha*gamma*x1*x1
        delta_si= b_si*b_si -4*a_si*c_si
        sol1=(-b_si - np.sqrt(delta_si))/(2*a_si)
        sol2=(-b_si + np.sqrt(delta_si))/(2*a_si)
        if sol1<0:
            z1=sol2
        else:
            z1=sol1
        c1=x+y+2*z+c-x1-y1-2*z1
        d1=z+d-z1
        Xfeo=x1/(x1+y1+z1+u+m+n)
        Xmw=1.148*Xfeo + 1.319*Xfeo*Xfeo
        sigmamet=a1+b1+c1+d1
        Kdcalc=(a1*c1)/(Xmw*sigmamet*sigmamet)
        DeltaK=Kdcalc-KdO
        return(DeltaK)
    #on solve la fonction pour x'
    x0=(x+a)*1e-5 #low pressure needs low initial guess
    sol=opt.fsolve(Fesolve,x0)
    #calcul des moles finales DeltaK donne la précision
    DeltaK,a1,b1,c1,d1,x1,y1,z1=molfinale(sol,KdNi,KdSi,KdO,a,b,c,d,x,y,z,u,m,n)

    #calcul of missing elements
    Cotot=moltotsil[2]+moltotmet[2]
    Crtot=moltotsil[5]+moltotmet[5]
    Vtot=moltotsil[4]+moltotmet[4]
    Cosil=Cotot*sol/(KdCo*a1+sol)
    Crsil=Crtot*sol/(KdCr*a1+sol)
    Comet=Cotot-Cosil
    Crmet=Crtot-Crsil
    sigmet=a1+b1+c1+d1+Comet+Crmet
    sigsil=sol+y1+z1+u+m+n+Cosil+Crsil
    Rfe=a1/sol
    Vsil= Vtot/(1+KdV*np.sqrt(sigsil/sigmet)*(Rfe)**(3/2))
    Vmet=Vtot-Vsil
    #new moles
    moltotmet[0]=a1
    moltotmet[1]=b1
    moltotmet[2]=Comet
    moltotmet[3]=d1
    moltotmet[4]=Vmet
    moltotmet[5]=Crmet
    moltotmet[6]=c1
    moltotsil[0]=sol
    moltotsil[1]=y1
    moltotsil[2]=Cosil
    moltotsil[3]=z1
    moltotsil[4]=Vsil
    moltotsil[5]=Crsil
    
    #Normalisation because of Cr, Co and V
    molesil=0
    molemet=0
    for i in range(len(moltotsil)):
        molesil=molesil+moltotsil[i]
    for i in range(len(moltotmet)):
        molemet=molemet +moltotmet[i]
    for i in range(len(moltotsil)):
        moltotsil[i]=moltotsil[i]/molesil
    for i in range(len(moltotmet)):
        moltotmet[i]=moltotmet[i]/molemet
    Metal=np.zeros(len(moltotmet))
    Silicate=np.zeros(len(moltotsil))
    massesil=0
    massemet=0
    for i in range(len(moltotsil)):
        Silicate[i]=moltotsil[i]*massemolsil[i]
        massesil=massesil+Silicate[i]
    for i in range(len(moltotmet)):
        Metal[i]=moltotmet[i]*massemolmet[i]
        massemet=massemet+Metal[i]
    for i in range(len(Metal)):
        Metal[i]=Metal[i]/massemet
    for i in range(len(Silicate)):
        Silicate[i]=Silicate[i]/massesil
    
    return(Metal,Silicate)
"function calculating the evolution of composition for one fc and Kds calculated from P and T"

def Compovsfrac(frac,fc,m_sil,m_met,Composil1,Compomet1,Composil2,Compomet2,KdNi,KdCo,KdSi,KdV,KdCr,KdO):
    Metal=np.zeros([len(frac),len(Compomet1)])
    Silicate=np.zeros([len(frac),len(Composil1)])
    for i in range(len(frac)):
        if frac[i]<fc:
            metal,silicate=Compoimpact(m_sil[i],m_met[i],Composil1,Compomet1,KdNi[i],KdCo[i],KdSi[i],KdV[i],KdCr[i],KdO[i])
            for j in range(len(Compomet1)):
                Metal[i][j]=metal[j]
            for j in range(len(Composil1)):
                Silicate[i][j]=silicate[j]
        else:
            metal,silicate=Compoimpact(m_sil[i],m_met[i],Composil2,Compomet2,KdNi[i],KdCo[i],KdSi[i],KdV[i],KdCr[i],KdO[i])
            for j in range(len(Compomet1)):
                Metal[i][j]=metal[j]
            for j in range(len(Composil1)):
                Silicate[i][j]=silicate[j]  
    return(Silicate,Metal)
