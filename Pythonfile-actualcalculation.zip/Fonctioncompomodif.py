# -*- coding: utf-8 -*-
"""
Created on Tue Jan 18 13:57:07 2022

@author: vince
"""
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import Fonctiondefc as acc
import Fonctionalpha as al
import fonctions as fct
import DataFischer as Fis
def Compoparam(P,T,Compomet1,Compomet2,Composil1,Composil2,msil,mmet,Manteau_acc,Noyau_acc,fc,frac):
    
    col=len(frac)
    "calcul des Kd"
    paramNi=Fis.KdNi
    paramCo=Fis.KdCo
    paramV=Fis.KdV
    paramCr=Fis.KdCr
    paramSi=Fis.KdSi
    paramO=Fis.KdO


    KdNi=np.zeros(col)
    KdCo=np.zeros(col)
    KdV=np.zeros(col)
    KdCr=np.zeros(col)
    KdSi=np.zeros(col)
    KdO=np.zeros(col)
    
    logNi=fct.logKd(paramNi,P,T)
    KdNi=10**logNi
    logCo=fct.logKd(paramCo,P,T)
    KdCo=10**logCo
    logV=fct.logKd(paramV,P,T)
    KdV=10**logV
    logCr=fct.logKd(paramCr,P,T)
    KdCr=10**logCr
    logSi=fct.logKd(paramSi,P,T)
    KdSi=10**logSi
    logO=fct.logKd(paramO,P,T)
    KdO=10**logO
    "Calcul des compos"
#    massemolmet=acc.massemolmet
#    massemolsil=acc.massemolsil
    "On fait une matrice par élément et par phase"
    Fe=np.zeros(col)
    FeO=np.zeros(col)
    NiO=np.zeros(col)
    Ni=np.zeros(col)
    Co=np.zeros(col)
    CoO=np.zeros(col)
    Si=np.zeros(col)
    SiO=np.zeros(col)
    V=np.zeros(col)
    VO=np.zeros(col)
    Cr=np.zeros(col)
    CrO=np.zeros(col)
    AlO=np.zeros(col)
    CaO=np.zeros(col)
    MgO=np.zeros(col)
    O=np.zeros(col)
    Fef=np.zeros(col)
    FeOf=np.zeros(col)
    NiOf=np.zeros(col)
    Nif=np.zeros(col)
    Cof=np.zeros(col)
    CoOf=np.zeros(col)
    Sif=np.zeros(col)
    SiOf=np.zeros(col)
    Vf=np.zeros(col)
    VOf=np.zeros(col)
    Crf=np.zeros(col)
    CrOf=np.zeros(col)
    AlOf=np.zeros(col)
    CaOf=np.zeros(col)
    MgOf=np.zeros(col)
    Of=np.zeros(col)

    
    for j in range(col):
        if frac[j]<fc:
            met,sil=acc.Compoimpact(msil[j],mmet[j],Composil1,Compomet1,KdNi[j],KdCo[j],KdSi[j],KdV[j],KdCr[j],KdO[j])
            Fe[j]=met[0]
            FeO[j]=sil[0]
            Ni[j]=met[1]
            NiO[j]=sil[1]
            Co[j]=met[2]
            CoO[j]=sil[2]
            Si[j]=met[3]
            SiO[j]=sil[3]
            V[j]=met[4]
            VO[j]=sil[4]
            Cr[j]=met[5]
            CrO[j]=sil[5]
            O[j]=met[6]
            AlO[j]=sil[6]
            CaO[j]=sil[7]
            MgO[j]=sil[8]
        else:
            met,sil=acc.Compoimpact(msil[j],mmet[j],Composil2,Compomet2,KdNi[j],KdCo[j],KdSi[j],KdV[j],KdCr[j],KdO[j])
            Fe[j]=met[0]
            FeO[j]=sil[0]
            Ni[j]=met[1]
            NiO[j]=sil[1]
            Co[j]=met[2]
            CoO[j]=sil[2]
            Si[j]=met[3]
            SiO[j]=sil[3]
            V[j]=met[4]
            VO[j]=sil[4]
            Cr[j]=met[5]
            CrO[j]=sil[5]
            O[j]=met[6]
            AlO[j]=sil[6]
            CaO[j]=sil[7]
            MgO[j]=sil[8]
    
    
    Fef[0]=Fe[0]
    Nif[0]=Ni[0]
    Cof[0]=Co[0]
    Sif[0]=Si[0]
    Vf[0]=V[0]
    Crf[0]=Cr[0]
    Of[0]=O[0]
    FeOf[0]=FeO[0]
    NiOf[0]=NiO[0]
    CoOf[0]=CoO[0]
    SiOf[0]=SiO[0]
    VOf[0]=VO[0]
    CrOf[0]=CrO[0]
    AlOf[0]=AlO[0]
    CaOf[0]=CaO[0]
    MgOf[0]=MgO[0]
    for j in range(1,col):
        Fef[j]=(Noyau_acc[j-1]*Fef[j-1] +mmet[j]*Fe[j])/Noyau_acc[j]
        FeOf[j]=(Manteau_acc[j-1]*FeOf[j-1]+msil[j]*FeO[j])/Manteau_acc[j]
        Nif[j]=(Noyau_acc[j-1]*Nif[j-1] +mmet[j]*Ni[j])/Noyau_acc[j]
        Cof[j]=(Noyau_acc[j-1]*Cof[j-1] +mmet[j]*Co[j])/Noyau_acc[j]
        Sif[j]=(Noyau_acc[j-1]*Sif[j-1] +mmet[j]*Si[j])/Noyau_acc[j]
        Vf[j]=(Noyau_acc[j-1]*Vf[j-1] +mmet[j]*V[j])/Noyau_acc[j]
        Crf[j]=(Noyau_acc[j-1]*Crf[j-1] +mmet[j]*Cr[j])/Noyau_acc[j]
        Of[j]=(Noyau_acc[j-1]*Of[j-1] +mmet[j]*O[j])/Noyau_acc[j]
        NiOf[j]=(Manteau_acc[j-1]*NiOf[j-1]+msil[j]*NiO[j])/Manteau_acc[j]
        CoOf[j]=(Manteau_acc[j-1]*CoOf[j-1]+msil[j]*CoO[j])/Manteau_acc[j]
        SiOf[j]=(Manteau_acc[j-1]*SiOf[j-1]+msil[j]*SiO[j])/Manteau_acc[j]
        VOf[j]=(Manteau_acc[j-1]*VOf[j-1]+msil[j]*VO[j])/Manteau_acc[j]
        CrOf[j]=(Manteau_acc[j-1]*CrOf[j-1]+msil[j]*CrO[j])/Manteau_acc[j]
        AlOf[j]=(Manteau_acc[j-1]*AlOf[j-1]+msil[j]*AlO[j])/Manteau_acc[j]
        CaOf[j]=(Manteau_acc[j-1]*CaOf[j-1]+msil[j]*CaO[j])/Manteau_acc[j]
        MgOf[j]=(Manteau_acc[j-1]*MgOf[j-1]+msil[j]*MgO[j])/Manteau_acc[j]
    return(Fef,FeOf,Nif,NiOf,Cof,CoOf,Sif,SiOf,Vf,VOf,Crf,CrOf,Of,AlOf,CaOf,MgOf,Fe,FeO,Ni,NiO,Co,CoO,Si,SiO,V,VO,Cr,CrO,O,AlO,CaO,MgO)