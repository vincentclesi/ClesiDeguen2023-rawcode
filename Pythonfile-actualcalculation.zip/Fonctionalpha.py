# -*- coding: utf-8 -*-
"""
Created on Tue Oct  6 11:15:53 2020

@author: vince
"""
import fonctions as fct
import numpy as np
import DataFischer as Fis
import Fonctiondefc as acc

"Functions when fc and alpha are known"
def ParamP(Facteur,Pn,frac,alpha,fc):
    P=np.zeros([len(Facteur),len(frac)])
    T=np.zeros([len(Facteur),len(frac)])
    for i in range(len(Facteur)):
        Ptest=fct.PeqWborne(Facteur[i],frac,alpha,fc,Pn)
        Ttest=1940*(Ptest*1e-9/(29) +1)**(1/1.9)
        for j in range(len(frac)):
            P[i][j]=Ptest[j]
            T[i][j]=Ttest[j]
    return(P,T)
Cpm = 1000;
Cps = 500; 
mu_sil = 1e18;
D_sil= 1e-6;
Rnf=3470000
"function calculating the composition for Peq and Teq"
def Compoparam(P,T,Compomet1,Compomet2,Composil1,Composil2,msil,mmet,Manteau_acc,Noyau_acc,fc,frac):
    A=np.shape(P)
    line=A[0]
    col=A[1]
    "calcul of Kd"
    paramNi=Fis.KdNi
    paramCo=Fis.KdCo
    paramV=Fis.KdV
    paramCr=Fis.KdCr
    paramSi=Fis.KdSi
    paramO=Fis.KdO


    KdNi=np.zeros([line,col])
    KdCo=np.zeros([line,col])
    KdV=np.zeros([line,col])
    KdCr=np.zeros([line,col])
    KdSi=np.zeros([line,col])
    KdO=np.zeros([line,col])
    for i in range(line):
        logNi=fct.logKd(paramNi,P[i],T[i])
        KdNi[i]=10**logNi
        logCo=fct.logKd(paramCo,P[i],T[i])
        KdCo[i]=10**logCo
        logV=fct.logKd(paramV,P[i],T[i])
        KdV[i]=10**logV
        logCr=fct.logKd(paramCr,P[i],T[i])
        KdCr[i]=10**logCr
        logSi=fct.logKd(paramSi,P[i],T[i])
        KdSi[i]=10**logSi
        logO=fct.logKd(paramO,P[i],T[i])
        KdO[i]=10**logO

    "1 matrix per elemnt and phase"
    Fe=np.zeros([line,col])
    FeO=np.zeros([line,col])
    NiO=np.zeros([line,col])
    Ni=np.zeros([line,col])
    Co=np.zeros([line,col])
    CoO=np.zeros([line,col])
    Si=np.zeros([line,col])
    SiO=np.zeros([line,col])
    V=np.zeros([line,col])
    VO=np.zeros([line,col])
    Cr=np.zeros([line,col])
    CrO=np.zeros([line,col])
    AlO=np.zeros([line,col])
    CaO=np.zeros([line,col])
    MgO=np.zeros([line,col])
    O=np.zeros([line,col])
    Fef=np.zeros([line,col])
    FeOf=np.zeros([line,col])
    NiOf=np.zeros([line,col])
    Nif=np.zeros([line,col])
    Cof=np.zeros([line,col])
    CoOf=np.zeros([line,col])
    Sif=np.zeros([line,col])
    SiOf=np.zeros([line,col])
    Vf=np.zeros([line,col])
    VOf=np.zeros([line,col])
    Crf=np.zeros([line,col])
    CrOf=np.zeros([line,col])
    AlOf=np.zeros([line,col])
    CaOf=np.zeros([line,col])
    MgOf=np.zeros([line,col])
    Of=np.zeros([line,col])

    for i in range(line):
        for j in range(col):
            if frac[j]<fc:
                met,sil=acc.Compoimpact(msil[j],mmet[j],Composil1,Compomet1,KdNi[i][j],KdCo[i][j],KdSi[i][j],KdV[i][j],KdCr[i][j],KdO[i][j])
                Fe[i][j]=met[0]
                FeO[i][j]=sil[0]
                Ni[i][j]=met[1]
                NiO[i][j]=sil[1]
                Co[i][j]=met[2]
                CoO[i][j]=sil[2]
                Si[i][j]=met[3]
                SiO[i][j]=sil[3]
                V[i][j]=met[4]
                VO[i][j]=sil[4]
                Cr[i][j]=met[5]
                CrO[i][j]=sil[5]
                O[i][j]=met[6]
                AlO[i][j]=sil[6]
                CaO[i][j]=sil[7]
                MgO[i][j]=sil[8]
            else:
                met,sil=acc.Compoimpact(msil[j],mmet[j],Composil2,Compomet2,KdNi[i][j],KdCo[i][j],KdSi[i][j],KdV[i][j],KdCr[i][j],KdO[i][j])
                Fe[i][j]=met[0]
                FeO[i][j]=sil[0]
                Ni[i][j]=met[1]
                NiO[i][j]=sil[1]
                Co[i][j]=met[2]
                CoO[i][j]=sil[2]
                Si[i][j]=met[3]
                SiO[i][j]=sil[3]
                V[i][j]=met[4]
                VO[i][j]=sil[4]
                Cr[i][j]=met[5]
                CrO[i][j]=sil[5]
                O[i][j]=met[6]
                AlO[i][j]=sil[6]
                CaO[i][j]=sil[7]
                MgO[i][j]=sil[8]
    
    for i in range(line):
        Fef[i][0]=Fe[i][0]
        Nif[i][0]=Ni[i][0]
        Cof[i][0]=Co[i][0]
        Sif[i][0]=Si[i][0]
        Vf[i][0]=V[i][0]
        Crf[i][0]=Cr[i][0]
        Of[i][0]=O[i][0]
        FeOf[i][0]=FeO[i][0]
        NiOf[i][0]=NiO[i][0]
        CoOf[i][0]=CoO[i][0]
        SiOf[i][0]=SiO[i][0]
        VOf[i][0]=VO[i][0]
        CrOf[i][0]=CrO[i][0]
        AlOf[i][0]=AlO[i][0]
        CaOf[i][0]=CaO[i][0]
        MgOf[i][0]=MgO[i][0]
        for j in range(1,col):
            Fef[i][j]=(Noyau_acc[j-1]*Fef[i][j-1] +mmet[j]*Fe[i][j])/Noyau_acc[j]
            FeOf[i][j]=(Manteau_acc[j-1]*FeOf[i][j-1]+msil[j]*FeO[i][j])/Manteau_acc[j]
            Nif[i][j]=(Noyau_acc[j-1]*Nif[i][j-1] +mmet[j]*Ni[i][j])/Noyau_acc[j]
            Cof[i][j]=(Noyau_acc[j-1]*Cof[i][j-1] +mmet[j]*Co[i][j])/Noyau_acc[j]
            Sif[i][j]=(Noyau_acc[j-1]*Sif[i][j-1] +mmet[j]*Si[i][j])/Noyau_acc[j]
            Vf[i][j]=(Noyau_acc[j-1]*Vf[i][j-1] +mmet[j]*V[i][j])/Noyau_acc[j]
            Crf[i][j]=(Noyau_acc[j-1]*Crf[i][j-1] +mmet[j]*Cr[i][j])/Noyau_acc[j]
            Of[i][j]=(Noyau_acc[j-1]*Of[i][j-1] +mmet[j]*O[i][j])/Noyau_acc[j]
            NiOf[i][j]=(Manteau_acc[j-1]*NiOf[i][j-1]+msil[j]*NiO[i][j])/Manteau_acc[j]
            CoOf[i][j]=(Manteau_acc[j-1]*CoOf[i][j-1]+msil[j]*CoO[i][j])/Manteau_acc[j]
            SiOf[i][j]=(Manteau_acc[j-1]*SiOf[i][j-1]+msil[j]*SiO[i][j])/Manteau_acc[j]
            VOf[i][j]=(Manteau_acc[j-1]*VOf[i][j-1]+msil[j]*VO[i][j])/Manteau_acc[j]
            CrOf[i][j]=(Manteau_acc[j-1]*CrOf[i][j-1]+msil[j]*CrO[i][j])/Manteau_acc[j]
            AlOf[i][j]=(Manteau_acc[j-1]*AlOf[i][j-1]+msil[j]*AlO[i][j])/Manteau_acc[j]
            CaOf[i][j]=(Manteau_acc[j-1]*CaOf[i][j-1]+msil[j]*CaO[i][j])/Manteau_acc[j]
            MgOf[i][j]=(Manteau_acc[j-1]*MgOf[i][j-1]+msil[j]*MgO[i][j])/Manteau_acc[j]
    return(Fef,FeOf,Nif,NiOf,Cof,CoOf,Sif,SiOf,Vf,VOf,Crf,CrOf,Of,AlOf,CaOf,MgOf,Fe,FeO,Ni,NiO,Co,CoO,Si,SiO,V,VO,Cr,CrO,O,AlO,CaO,MgO)
"function that lead the calculation of T before core is compressed, and after compression"
def CalculTparam(Fe,Ni,Co,V,Cr,Si,O,Px,Tx,Pn,Rn,K0,K1,gamma0,gammainf,beta):
    l=np.shape(Px)
    
    rho0th=[7019,7900,8900,2210,6100,7190,365.45] 
    alphaSi=-0.91 #effeect of Si on density
    alphaO=-1.3 #effect of O on density 
    rho0=np.zeros([l[0],l[1]])
    for i in range(l[0]):
        for j in range(l[1]):
            rhoint=rho0th[0]*Fe[i][j]+rho0th[1]*Ni[i][j]+rho0th[2]*Co[i][j]+rho0th[4]*V[i][j]+rho0th[5]*Cr[i][j]
            rho0[i][j]=rhoint*np.exp(alphaSi*Si[i][j])*np.exp(alphaO*O[i][j])
    Tcmb=np.zeros([l[0],l[1]])
    rho1=np.zeros([l[0],l[1]])
    for i in range(l[0]):
        T,rho=fct.T_simpleanalytique(Px[i],Tx[i],Pn,K0,K1,rho0[i],gamma0,gammainf,beta)
        for j in range(l[1]):
            Tcmb[i][j]=T[j]
            rho1[i][j]=rho[j]
    #ajout de la première étape pour avoir la partie entre R=0 et Rn[0]
    "adding point for T and P between 0 et 0.05"
    frac2=np.linspace(0.0,0.0495,100)
    supplen=len(frac2)
    rho02=np.zeros([l[0],l[1]+supplen])
    rho2=np.zeros([l[0],l[1]+supplen])
    Rn2=np.zeros(len(Rn)+supplen)
    Tcmb2=np.zeros([l[0],l[1]+supplen])
    Pn2=np.zeros(len(Pn)+supplen)
    for i in range(l[0]):
        for j in range(0,supplen):
            rho02[i][j]=rho0[i][0]
            rho2[i][j]=rho1[i][0]
            Tcmb2[i][j]=Tcmb[i][0]
            Rn2[j]=Rnf*frac2[j]**(1/3)
            Pn2[j]=Pn[0]
        for j in range(supplen,l[1]+supplen):
            Rn2[j]=Rn[j-supplen]
            Pn2[j]=Pn[j-supplen]
            Tcmb2[i][j]=Tcmb[i][j-supplen]
            rho02[i][j]=rho0[i][j-supplen]
            rho2[i][j]=rho1[i][j-supplen]
#    print(rho2)
    PCMBfin=Pn2[len(Pn2)-1]
    # Pfinal=np.zeros(l[0],l[1]+supplen)
    rhofin=np.zeros([l[0],l[1]+supplen])
    Tfin=np.zeros([l[0],l[1]+supplen])
    
    Pfinal= fct.Pressioncore(Rn2,PCMBfin)
    for i in range(l[0]):
        Tfinal,rhofinal=fct.T_simpleanalytique(Pn2,Tcmb2[i],Pfinal,K0,K1,rho02[i],gamma0,gammainf,beta)
        for j in range(l[1]+supplen):
            Tfin[i][j]=Tfinal[j]
            rhofin[i][j]=rhofinal[j]
    return(Tcmb2,Tfin,rho2,rhofin,rho02)
def CalculTmoyen(Fef,Nif,Cof,Vf,Crf,Sif,Of,Px,Tx,Pn,Rn,K0,K1,gamma0,gammainf,beta):
    l=np.shape(Px)

    rho0th=[7019,7900,8900,2210,6100,7190,365.45] #on se fait pas trop chier au début avec les interactions
    alphaSi=-0.91
    alphaO=-1.3
    rho0=np.zeros([l[0],l[1]])
    for i in range(l[0]):
        for j in range(l[1]):
            rhoint=rho0th[0]*Fef[i][l[1]-1]+rho0th[1]*Nif[i][l[1]-1]+rho0th[2]*Cof[i][l[1]-1]+rho0th[4]*Vf[i][l[1]-1]+rho0th[5]*Crf[i][l[1]-1]
            rho0[i][j]=rhoint*np.exp(alphaSi*Sif[i][l[1]-1])*np.exp(alphaO*Of[i][l[1]-1])
    Tcmb=np.zeros([l[0],l[1]])
    rho1=np.zeros([l[0],l[1]])
    for i in range(l[0]):
        T,rho=fct.T_simpleanalytique(Px[i],Tx[i],Pn,K0,K1,rho0[i],gamma0,gammainf,beta)
        for j in range(l[1]):
            Tcmb[i][j]=T[j]
            rho1[i][j]=rho[j]
    #ajout de la première étape pour avoir la partie entre R=0 et Rn[0]
    #ajout de la première étape pour avoir la partie entre R=0 et Rn[0]
    "adding point for T and P between 0 et 0.05"
    frac2=np.linspace(0.0,0.0495,100)
    supplen=len(frac2)
    rho02=np.zeros([l[0],l[1]+supplen])
    rho2=np.zeros([l[0],l[1]+supplen])
    Rn2=np.zeros(len(Rn)+supplen)
    Tcmb2=np.zeros([l[0],l[1]+supplen])
    Pn2=np.zeros(len(Pn)+supplen)
    for i in range(l[0]):
        for j in range(0,supplen):
            rho02[i][j]=rho0[i][0]
            rho2[i][j]=rho1[i][0]
            Tcmb2[i][j]=Tcmb[i][0]
            Rn2[j]=Rnf*frac2[j]**(1/3)
            Pn2[j]=Pn[0]
        for j in range(supplen,l[1]+supplen):
            Rn2[j]=Rn[j-supplen]
            Pn2[j]=Pn[j-supplen]
            Tcmb2[i][j]=Tcmb[i][j-supplen]
            rho02[i][j]=rho0[i][j-supplen]
            rho2[i][j]=rho1[i][j-supplen]
#    print(rho2)
    PCMBfin=Pn2[len(Pn2)-1]
    # Pfinal=np.zeros(l[0],l[1]+supplen)
    rhofin=np.zeros([l[0],l[1]+supplen])
    Tfin=np.zeros([l[0],l[1]+supplen])
    
    Pfinal= fct.Pressioncore(Rn2,PCMBfin)
    for i in range(l[0]):
        Tfinal,rhofinal=fct.T_simpleanalytique(Pn2,Tcmb2[i],Pfinal,K0,K1,rho02[i],gamma0,gammainf,beta)
        for j in range(l[1]+supplen):
            Tfin[i][j]=Tfinal[j]
            rhofin[i][j]=rhofinal[j]
    return(Tcmb2,Tfin,rho2,rhofin,rho02)
    
"Fonctions with dissipation"    
def CalculTdiss(Fe,Ni,Co,V,Cr,Si,O,Px,Tx,Pn,Rn,K0,K1,gamma0,gammainf,beta,rhosil,epsilon,step):
    l=np.shape(Px)
    
    rho0th=[7019,7900,8900,2210,6100,7190,365.45] #on se fait pas trop chier au début avec les interactions
    alphaSi=-0.91
    alphaO=-1.3
    rho0=np.zeros([l[0],l[1]])
    for i in range(l[0]):
        for j in range(l[1]):
            rhoint=rho0th[0]*Fe[i][j]+rho0th[1]*Ni[i][j]+rho0th[2]*Co[i][j]+rho0th[4]*V[i][j]+rho0th[5]*Cr[i][j]
            rho0[i][j]=rhoint*np.exp(alphaSi*Si[i][j])*np.exp(alphaO*O[i][j])
    Tcmb=np.zeros([l[0],l[1]])
    rho1=np.zeros([l[0],l[1]])
    for i in range(l[0]):
        T,rho=fct.T_dissipation(Px[i],Tx[i],Pn,K0,K1,rho0,gamma0,gammainf,beta,rhosil,epsilon,step)
        for j in range(l[1]):
            Tcmb[i][j]=T[j]
            rho1[i][j]=rho[j]
    "adding point for T and P between 0 et 0.05"
    frac2=np.linspace(0.0,0.0495,100)
    supplen=len(frac2)
    rho02=np.zeros([l[0],l[1]+supplen])
    rho2=np.zeros([l[0],l[1]+supplen])
    Rn2=np.zeros(len(Rn)+supplen)
    Tcmb2=np.zeros([l[0],l[1]+supplen])
    Pn2=np.zeros(len(Pn)+supplen)
    for i in range(l[0]):
        for j in range(0,supplen):
            rho02[i][j]=rho0[i][0]
            rho2[i][j]=rho1[i][0]
            Tcmb2[i][j]=Tcmb[i][0]
            Rn2[j]=Rnf*frac2[j]**(1/3)
            Pn2[j]=Pn[0]
        for j in range(supplen,l[1]+supplen):
            Rn2[j]=Rn[j-supplen]
            Pn2[j]=Pn[j-supplen]
            Tcmb2[i][j]=Tcmb[i][j-supplen]
            rho02[i][j]=rho0[i][j-supplen]
            rho2[i][j]=rho1[i][j-supplen]
#    print(rho2)
    PCMBfin=Pn2[len(Pn2)-1]
    # Pfinal=np.zeros(l[0],l[1]+supplen)
    rhofin=np.zeros([l[0],l[1]+supplen])
    Tfin=np.zeros([l[0],l[1]+supplen])
    
    Pfinal= fct.Pressioncore(Rn2,PCMBfin)
    for i in range(l[0]):
        Tfinal,rhofinal=fct.T_simpleanalytique(Pn2,Tcmb2[i],Pfinal,K0,K1,rho02[i],gamma0,gammainf,beta)
        for j in range(l[1]):
            Tfin[i][j]=Tfinal[j]
            rhofin[i][j]=rhofinal[j]
    return(Tcmb,Tfin,rho1,rhofin)
    
def CalculTmoyendiss(Fef,Nif,Cof,Vf,Crf,Sif,Of,Px,Tx,Pn,Rn,K0,K1,gamma0,gammainf,beta,rhosil,epsilon,step):
    l=np.shape(Px)

    rho0th=[7019,7900,8900,2210,6100,7190,365.45] #on se fait pas trop chier au début avec les interactions
    alphaSi=-0.91
    alphaO=-1.3
    rho0=np.zeros([l[0],l[1]])
    for i in range(l[0]):
        for j in range(l[1]):
            rhoint=rho0th[0]*Fef[i][l[1]-1]+rho0th[1]*Nif[i][l[1]-1]+rho0th[2]*Cof[i][l[1]-1]+rho0th[4]*Vf[i][l[1]-1]+rho0th[5]*Crf[i][l[1]-1]
            rho0[i][j]=rhoint*np.exp(alphaSi*Sif[i][l[1]-1])*np.exp(alphaO*Of[i][l[1]-1])
    Tcmb=np.zeros([l[0],l[1]])
    rho1=np.zeros([l[0],l[1]])
    for i in range(l[0]):
        T,rho=fct.T_dissipation(Px[i],Tx[i],Pn,K0,K1,rho0,gamma0,gammainf,beta,rhosil,epsilon,step)
        for j in range(l[1]):
            Tcmb[i][j]=T[j]
            rho1[i][j]=rho[j]
    "adding point for T and P between 0 et 0.05"
    frac2=np.linspace(0.0,0.0495,100)
    supplen=len(frac2)
    rho02=np.zeros([l[0],l[1]+supplen])
    rho2=np.zeros([l[0],l[1]+supplen])
    Rn2=np.zeros(len(Rn)+supplen)
    Tcmb2=np.zeros([l[0],l[1]+supplen])
    Pn2=np.zeros(len(Pn)+supplen)
    for i in range(l[0]):
        for j in range(0,supplen):
            rho02[i][j]=rho0[i][0]
            rho2[i][j]=rho1[i][0]
            Tcmb2[i][j]=Tcmb[i][0]
            Rn2[j]=Rnf*frac2[j]**(1/3)
            Pn2[j]=Pn[0]
        for j in range(supplen,l[1]+supplen):
            Rn2[j]=Rn[j-supplen]
            Pn2[j]=Pn[j-supplen]
            Tcmb2[i][j]=Tcmb[i][j-supplen]
            rho02[i][j]=rho0[i][j-supplen]
            rho2[i][j]=rho1[i][j-supplen]
#    print(rho2)
    PCMBfin=Pn2[len(Pn2)-1]
    # Pfinal=np.zeros(l[0],l[1]+supplen)
    rhofin=np.zeros([l[0],l[1]+supplen])
    Tfin=np.zeros([l[0],l[1]+supplen])
    
    Pfinal= fct.Pressioncore(Rn2,PCMBfin)
    for i in range(l[0]):
        Tfinal,rhofinal=fct.T_simpleanalytique(Pn2,Tcmb2[i],Pfinal,K0,K1,rho02[i],gamma0,gammainf,beta)
        for j in range(l[1]):
            Tfin[i][j]=Tfinal[j]
            rhofin[i][j]=rhofinal[j]
    return(Tcmb,Tfin,rho1,rhofin)
def best_fitall(composil,compomet,P,F,T,Q, Tmoy,Qmoy,ref,errmax,poids): #element = str
    size=np.shape(composil)
#    nel=size[1]
    errmoy=[]
    sigma=0
    for j in range(len(poids)):
        sigma=sigma+poids[j]
    
    for i in range(1,size[0]): # on calcule err moyenne
        delta=0
        
        for j in range(0,size[1]): 
            delta=delta + np.abs((1-composil[i][j]/ref[j]))*poids[j]
            
        moy=delta/sigma
        errmoy.append(moy)
    
    #calcul 
    #je fais une liste des rapports -1
    
    errmin=min(errmoy)
    i_final=0
    for i in range(len(errmoy)):
        if errmoy[i] == errmin:
            i_final=i
    #on récupère tout dans un fichier
    output_best=[['Pbest','Fbest','Tbest','Qbest','Tmoy best','Qmoy best'],[P[i_final],F[i_final],T[i_final],Q[i_final],Tmoy[i_final],Qmoy[i_final]]]
    composil_best=[composil[0],composil[i_final+1]]
    compomet_best=[compomet[0],compomet[i_final+1]]
    error=['Minimum error',errmin]
    #on regarde pour les erreurs les plus faibles (errmax)
    indices_fit=[]
    output_fit=[['Pfit','Ffit','Tfit','Qfit','Tmoyfit','Qmoyfit']]
    composil_fit=[composil[0]]
    compomet_fit=[compomet[0]]
    for i in range(len(errmoy)):
        if errmoy[i]<errmax:
            ifit=i
            indices_fit.append(ifit)
    if len(indices_fit)==0:
         output_fit.append(['No solutions'])
         composil_fit.append(['No solutions'])
         compomet_fit.append(['No solutions'])
    else:
         for i in range(len(indices_fit)):
             k=indices_fit[i]
             output=[P[k],F[k],T[k],Q[k],Tmoy[k],Qmoy[k]]
             sil=composil[k+1]
             met=compomet[k+1]
             output_fit.append(output)
             composil_fit.append(sil)
             compomet_fit.append(met)
    n_sol=['Number of Solutions for '+str(round(errmax*100,3))+'% error',len(indices_fit)]
#    print(i_final)
#    print(errmoy)
    return(output_best,composil_best,compomet_best,error,output_fit,n_sol,composil_fit,compomet_fit)

"For the diffusion"
def Rdparam(frac,fc,alpha,Rmax,rhomoymet,rhomoysil):
    Rd=np.zeros(len(frac))
    v_stokes=np.zeros(len(frac))
    Pe=np.zeros(len(frac))
    for i in range(len(frac)):
        g=9.81*frac[i]**(2/3)
        Rd[i]=Rmax*((1-np.exp(-(frac[i]/fc)**alpha))/(1-np.exp(-(1/fc)**alpha)))
        v_stokes[i]=(2/9)*(rhomoymet[i]-rhomoysil[i])*g*(Rd[i]**2)/mu_sil
        Pe[i]=Rd[i]*v_stokes[i]/D_sil
    return(Rd,Pe,v_stokes)