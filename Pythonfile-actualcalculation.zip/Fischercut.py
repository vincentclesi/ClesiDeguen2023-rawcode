# -*- coding: utf-8 -*-
"""
Created on Wed Jun 10 16:27:53 2020

@author: vince
Test d'un modèle de calcul de l'entropie en fonction de la composition. 
ON devrait avoir un modèle qui fonctionne
"""

import numpy as np
import os
import scipy.special as spe #nécessaire pour la fonction gamma 
import scipy.optimize as opt
import math
import csv
import matplotlib.pyplot as plt
import time
import DataFischer as Fis
#import Massemolaire
"liste des paramètres utilisés"
G=6.6742*1e-11 #en N.m2/kg
g_constant= 9.81; 
rho0k=7874
rho_sil = 3300 #Constante en kg/m3
expo =[1,2.5,5,10,25,50,100,250,500,750,1000]#multiplieur pour le rayon en m plus tard
gamma0 = 1.735; #valeur de gruneisen donnée par anderson & Ahrens (1994)
K0 = 109.7*1e9 #en Pa
dK=4.66 #K' de Anderson et ahrens sans unité
Cpm = 1000;# Chaleur spécifiqque métal en J/kg.K, même valeur que dans le rapport
Cps = 500; # Cahleur spécifique silicate en J/kg.K, même valeur que dans le rapport
mu_sil = 1e18; # viscosité perovskite (Yamazaki 2001)
lambda_sil = 0.1 # en W.m-1.K.-1, conductivité thermique des silicates (oredre de grandeur)
lambda_met= 100 # en W.m-1.K-1, ordre de grandeur de la condutivité pour le métal
D_sil= 1e-6; #diffusivité en m2/s dans les silicates
Rd=100e3 #Rd en m
v_stokes= (2/9)*(rho0k-rho_sil)*g_constant*(Rd**2)/mu_sil
Pe = Rd*v_stokes/D_sil;
a = 1;  # valeur arbitraire de constante fois10^-9 pour le transfert en GPa
alpha=11e-6 #coeff de dilatation thermique en K-1 (pris à 25° pour l'acier)
"Masse molaires en g par mol. multiplier par 1e-3 pour les kg/mol"
MFe=55.845*1e-3 #transformé en kg/mol
MNi=58.6934*1e-3
MCo=58.9332*1e-3
MO=15.999*1e-3
MSi=28.0855*1e-3
MMg=24.305*1e-3
MAl=26.9815*1e-3
MV=50.9415*1e-3
MCr=51.9961*1e-3
MCa=40.078*1e-3
#Tm = 1940 # température liquidus en surface
"Rayon de la planète en fonction de laccretion"
RTf = 6370000 
PNf=136e9#Pression CMB en PA
Rnf=3470000 #•Rayon noyau final
MT=5.972e24 #masse terre en kilos
 # constante de gravitation. Si on veut changer, prendre g[i]
frac= np.linspace(0.05,1,20) ;

'extraction du coeff du polynôme'
data = csv.reader(open('CoeffEOSfit.csv','r'),dialect='excel')
rows=[]

for row in data:
    rows.append(row)
coeffrho=np.zeros(len(rows))
for i in range(len(rows)):
    coeffrho[i]=float(rows[i][0])
    
'transformation pour un coeff mieux'
coeff_norm=coeffrho/coeffrho[2]
"Test masse/rayon"
m_acc=np.zeros(len(frac))
R_acc=np.zeros(len(frac))
rhomoy=np.zeros(len(frac))
Rn=np.zeros(len(frac))
g_surf=np.zeros(len(frac))
for i in range(len(frac)):
    m_acc[i]=frac[i]*MT
    R_acc[i] = RTf*(frac[i]**(1/3))
    rhomoy[i] = m_acc[i]/((4/3)*np.pi*R_acc[i]**(3))
    Rn[i]=Rnf*frac[i]**(1/3)
    Vn=(4/3)*np.pi*Rn[i]**3
    Vm=(4/3)*np.pi*R_acc[i]**(3)-(4/3)*np.pi*Rn[i]**3
    g_surf[i]=G*m_acc[i]/(R_acc[i]**2)
"Première partie : calcul de la compo"
"d'abord la rhomoyenne du calcul de Fischer"
cut=0.5
rhomoymet=np.zeros(len(frac))
rhomoysil=np.zeros(len(frac))
PCMB=np.zeros(len(frac))
P50=np.zeros(len(frac))
T50=np.zeros(len(frac))
m_noyauacc=np.zeros(len(frac)) #masse cumulée de noyau
m_met=np.zeros(len(frac)) #masse métal qui est ajoutée au temps x
m_manteauacc=np.zeros(len(frac)) #masse cumulée du manteau
m_sil=np.zeros(len(frac)) #masse silicate accrétée au temps x
m_sil[0]=(1-Fis.Fracmetal[0])*m_acc[0]
m_met[0]=(Fis.Fracmetal[0])*m_acc[0]
m_manteauacc[0]=m_sil[0]
m_noyauacc[0]=m_met[0]
Vn=(4/3)*np.pi*Rn[0]**3
Vm=(4/3)*np.pi*R_acc[0]**(3)-(4/3)*np.pi*Rn[0]**3
rhomoymet[0]=m_noyauacc[0]/Vn
rhomoysil[0]=m_manteauacc[0]/Vm 
fact=(4/3)*np.pi*G*rhomoysil[0]
PCMB[0]=fact*((0.5*rhomoysil[0]*(R_acc[0]**2-Rn[0]**2))+ Rn[0]**3*(rhomoymet[0]-rhomoysil[0])*(1/(Rn[0])-1/R_acc[0]))
R50= (R_acc[0]-Rn[0])/2 + Rn[0]
P50[0]=fact*((0.5*rhomoysil[0]*(R_acc[0]**2-R50**2))+ Rn[0]**3*(rhomoymet[0]-rhomoysil[0])*(1/(R50)-1/R_acc[0]))
T50[0]= 1940*(P50[0]*1e-9/(29) +1)**(1/1.9)
for i in range(1,len(frac),1):
    if frac[i] < cut:
        met=Fis.Fracmetal[0]
        m_met[i]=(m_acc[i]-m_acc[i-1])*met
        m_sil[i]=(m_acc[i]-m_acc[i-1])*(1-met)
        m_noyauacc[i]= m_noyauacc[i-1]+m_met[i]
        m_manteauacc[i]= m_manteauacc[i-1]+m_sil[i]
        Vn=(4/3)*np.pi*Rn[i]**3
        Vm=(4/3)*np.pi*R_acc[i]**(3)-(4/3)*np.pi*Rn[i]**3
        rhomoymet[i]=m_noyauacc[i]/Vn
        rhomoysil[i]=m_manteauacc[i]/Vm 
        fact=(4/3)*np.pi*G*rhomoysil[i]
        PCMB[i]=fact*((0.5*rhomoysil[i]*(R_acc[i]**2-Rn[i]**2))+ Rn[i]**3*(rhomoymet[i]-rhomoysil[i])*(1/(Rn[i])-1/R_acc[i]))
        R50= (R_acc[i]-Rn[i])/2 + Rn[i]
        P50[i]=fact*((0.5*rhomoysil[i]*(R_acc[i]**2-R50**2))+ Rn[i]**3*(rhomoymet[i]-rhomoysil[i])*(1/(R50)-1/R_acc[i]))
        T50[i]= 1940*(P50[i]*1e-9/(29) +1)**(1/1.9)
    else:
        met=Fis.Fracmetal[1]
        m_met[i]=(m_acc[i]-m_acc[i-1])*met
        m_sil[i]=(m_acc[i]-m_acc[i-1])*(1-met)
        m_noyauacc[i]= m_noyauacc[i-1]+m_met[i]
        m_manteauacc[i]= m_manteauacc[i-1]+m_sil[i]
        Vn=(4/3)*np.pi*Rn[i]**3
        Vm=(4/3)*np.pi*R_acc[i]**(3)-(4/3)*np.pi*Rn[i]**3
        rhomoymet[i]=m_noyauacc[i]/Vn
        rhomoysil[i]=m_manteauacc[i]/Vm 
        fact=(4/3)*np.pi*G*rhomoysil[i]
        PCMB[i]=fact*((0.5*rhomoysil[i]*(R_acc[i]**2-Rn[i]**2))+ Rn[i]**3*(rhomoymet[i]-rhomoysil[i])*(1/(Rn[i])-1/R_acc[i]))
        R50= (R_acc[i]-Rn[i])/2 + Rn[i]
        P50[i]=fact*((0.5*rhomoysil[i]*(R_acc[i]**2-R50**2))+ Rn[i]**3*(rhomoymet[i]-rhomoysil[i])*(1/(R50)-1/R_acc[i]))
        T50[i]= 1940*(P50[i]*1e-9/(29) +1)**(1/1.9)

"Profil des Kd avec accretion"
def logKd(param,P,T):
    Kd=np.zeros(len(P))
    for i in range(len(P)):
        Kd[i]=param[0]+param[1]/T[i]+param[2]*(P[i]*1e-9)/T[i]
    return(Kd)
paramNi=Fis.KdNi
paramCo=Fis.KdCo
paramV=Fis.KdV
paramCr=Fis.KdCr
paramSi=Fis.KdSi
paramO=Fis.KdO
logNi=logKd(paramNi,P50,T50)
logCo=logKd(paramCo,P50,T50)
logV=logKd(paramV,P50,T50)
logCr=logKd(paramCr,P50,T50)
logSi=logKd(paramSi,P50,T50)
logO=logKd(paramO,P50,T50)
KdNi=np.zeros(len(logNi))
KdCo=np.zeros(len(logCo))
KdV=np.zeros(len(logV))
KdCr=np.zeros(len(logCr))
KdSi=np.zeros(len(logSi))
KdO=np.zeros(len(logO))
for i in range(len(logNi)):
    KdNi[i]=10**logNi[i]
    KdCo[i]=10**logCo[i]
    KdV[i]= 10**logV[i]
    KdCr[i]=10**logCr[i]
    KdSi[i]=10**logSi[i]
    KdO[i]=10**logO[i]
plt.figure()
plt.plot(frac,KdO)
plt.plot(frac,KdSi)
plt.plot(frac,KdV)
plt.plot(frac,KdCr)
plt.legend(['O','Si','V', 'Cr'])
plt.title('Kd Elements lithophile')
plt.close()
plt.figure()
plt.plot(frac,KdNi)
plt.plot(frac,KdCo)
plt.legend(['Ni','Co'])
plt.title('Kd Elements sidérophiles')
plt.close()
#logKd=[logNI[0],]

"Définition des compos: "
"Pour le silicates en % d'oxydes "
Compomet1=[Fis.Fe[0],Fis.Ni[0],Fis.Co[0],Fis.Si[0],Fis.V[0],Fis.Cr[0],Fis.O[0]]
Compomet2=[Fis.Fe[1],Fis.Ni[1],Fis.Co[1],Fis.Si[1],Fis.V[1],Fis.Cr[1],Fis.O[1]]
Composil1=[Fis.FeO[0],Fis.NiO[0],Fis.CoO[0],Fis.SiO2[0],Fis.VO15[0],Fis.CrO[0],Fis.AlO15[0],Fis.CaO[0],Fis.MgO[0]]
Composil2=[Fis.FeO[1],Fis.NiO[1],Fis.CoO[1],Fis.SiO2[1],Fis.VO15[1],Fis.CrO[1],Fis.AlO15[1],Fis.CaO[1],Fis.MgO[1]]
massemolsil=[(MFe+MO),(MNi+MO),(MCo+MO),(MSi+2*MO),(MV+1.5*MO),(MCr+MO), (MAl+1.5*MO), (MCa+MO), (MMg+MO)]
massemolmet=[MFe,MNi,MCo,MSi,MV,MCr,MO]

Compomet=[Compomet1,Compomet2]
Composil=[Composil1,Composil2]
"Definition des compos initiales pour l'accrétion"
Composil_imp=np.zeros([len(frac),len(Composil1)])
Compomet_imp=np.zeros([len(frac),len(Composil1)])
for i in range(len(frac)):
    for j in range(len(Composil1)):
        if frac[i]<cut:
            Composil_imp[i][j]=Composil1[j]
        else:
            Composil_imp[i][j]=Composil2[j]
    for k in range(len(Compomet1)):
        if frac[i]<cut:
            Compomet_imp[i][k]=Compomet1[k]
        else:
            Compomet_imp[i][k]=Compomet2[k]
"Le modèle est basé sur Fischer/Rubie : on ne fait réagir que les impacteurs"
"on a besoin d'une fonction qui calcule la compo du métal et du silicate à chaque étape, puis on mélange les compos"
"les compo sont en fraction de masse initialement"
"On prend les mole initiales dans le silicate et le métal"
"Dans l'écriture de Rubie (a, b,xy)"
"fonction pour quand on a la solution, à mettre en intermédaire"
def molfinale(x1,KdNi,KdSi,KdO,a,b,c,d,x,y,z,u,m,n): #x1 doit avoir la bonne valeur!
    y1=x1*(y+b)/((x+a-x1)*KdNi+x1)
    a1=x+a-x1
    b1=y+b-y1
    alpha=z+d
    gamma=a1+b1+x+y+3*z+c-x1-y1+d
    sigma=x1+y1+u+m+n
    a_si=3*x1*x1 - KdSi*a1*a1
    b_si=-(gamma*x1*x1+ 3*alpha*x1*x1 +KdSi*sigma*a1*a1)
    c_si=alpha*gamma*x1*x1
    delta_si= b_si*b_si -4*a_si*c_si
    sol1=(-b_si - np.sqrt(delta_si))/(2*a_si)
    sol2=(-b_si + np.sqrt(delta_si))/(2*a_si)
    if sol1<0:
        z1=sol2
    else:
        z1=sol1
    c1=x+y+2*z+c-x1-y1-2*z1
    d1=z+d-z1
    Xfeo=x1/(x1+y1+z1+u+m+n)
    Xmw=1.148*Xfeo + 1.319*Xfeo*Xfeo
    sigmamet=a1+b1+c1+d1
    Kdcalc=(a1*c1)/(Xmw*sigmamet*sigmamet)
    DeltaK=Kdcalc-KdO
    return(DeltaK,a1,b1,c1,d1,x1,y1,z1)
def Compoimpact(m_sil,m_met,composil,compomet,KdNi,KdCo,KdSi,KdV,KdCr,KdO):
    moltotsil=np.zeros(len(composil))
    moltotmet=np.zeros(len(compomet))
    for i in range(len(composil)):
        moltotsil[i]=(m_sil*composil[i])/massemolsil[i]
    for j in range(len(Compomet1)):
        moltotmet[j]=(m_met*compomet[j])/massemolmet[j]
    #passage en écriture rubie 2011
    a=moltotmet[0]
    b=moltotmet[1]
    c=moltotmet[6]
    d=moltotmet[3]
    x=moltotsil[0]
    y=moltotsil[1]
    z=moltotsil[3]
    u=moltotsil[6]
    m=moltotsil[7]
    n=moltotsil[8]
#    print('vérifie le nickel initial:  '+str(y+b))
    def Fesolve(x1): #Fonction interne pour le solving
        y1=x1*(y+b)/((x+a-x1)*KdNi+x1)
        a1=x+a-x1
        b1=y+b-y1
        alpha=z+d
        gamma=a1+b1+x+y +3*z+c-x1-y1+d
        sigma=x1+y1+u+m+n
        a_si=3*x1*x1 - KdSi*a1*a1
        b_si=-(gamma*x1*x1+ 3*alpha*x1*x1 +KdSi*sigma*a1*a1)
        c_si=alpha*gamma*x1*x1
        delta_si= b_si*b_si -4*a_si*c_si
        sol1=(-b_si - np.sqrt(delta_si))/(2*a_si)
        sol2=(-b_si + np.sqrt(delta_si))/(2*a_si)
        if sol1<0:
            z1=sol2
        else:
            z1=sol1
        c1=x+y+2*z+c-x1-y1-2*z1
        d1=z+d-z1
        Xfeo=x1/(x1+y1+z1+u+m+n)
        Xmw=1.148*Xfeo + 1.319*Xfeo*Xfeo
        sigmamet=a1+b1+c1+d1
        Kdcalc=(a1*c1)/(Xmw*sigmamet*sigmamet)
        DeltaK=Kdcalc-KdO
        return(DeltaK)
    #on solve la fonction pour x'
    x0=(x+a)*1e-5 #on part proche de 0 pour le spression faibles
    sol=opt.fsolve(Fesolve,x0)
#    print('checke la sol:'+str(sol/x))
    #calcul des moles finales DeltaK donne la précision
    DeltaK,a1,b1,c1,d1,x1,y1,z1=molfinale(sol,KdNi,KdSi,KdO,a,b,c,d,x,y,z,u,m,n)
#    print('vérifie le nickel final:  '+str(y1))
    #calcul des éléments manquant
    Cotot=moltotsil[2]+moltotmet[2]
    Crtot=moltotsil[5]+moltotmet[5]
    Vtot=moltotsil[4]+moltotmet[4]
    Cosil=Cotot*sol/(KdCo*a1+sol)
    Crsil=Crtot*sol/(KdCr*a1+sol)
    Comet=Cotot-Cosil
    Crmet=Crtot-Crsil
    sigmet=a1+b1+c1+d1+Comet+Crmet
    sigsil=sol+y1+z1+u+m+n+Cosil+Crsil
    Rfe=a1/sol
    Vsil= Vtot/(1+KdV*np.sqrt(sigsil/sigmet)*(Rfe)**(3/2))
    Vmet=Vtot-Vsil
    #remplissage des moles
    moltotmet[0]=a1
    moltotmet[1]=b1
    moltotmet[2]=Comet
    moltotmet[3]=d1
    moltotmet[4]=Vmet
    moltotmet[5]=Crmet
    moltotmet[6]=c1
    moltotsil[0]=sol
    moltotsil[1]=y1
    moltotsil[2]=Cosil
    moltotsil[3]=z1
    moltotsil[4]=Vsil
    moltotsil[5]=Crsil
    #Pas besoin de plus car les suivants ne varient pas
    #Normalisation molaire
    molesil=0
    molemet=0
    for i in range(len(moltotsil)):
        molesil=molesil+moltotsil[i]
    for i in range(len(moltotmet)):
        molemet=molemet +moltotmet[i]
    for i in range(len(moltotsil)):
        moltotsil[i]=moltotsil[i]/molesil
    for i in range(len(moltotmet)):
        moltotmet[i]=moltotmet[i]/molemet
    Metal=np.zeros(len(moltotmet))
    Silicate=np.zeros(len(moltotsil))
    massesil=0
    massemet=0
    for i in range(len(moltotsil)):
        Silicate[i]=moltotsil[i]*massemolsil[i]
        massesil=massesil+Silicate[i]
    for i in range(len(moltotmet)):
        Metal[i]=moltotmet[i]*massemolmet[i]
        massemet=massemet+Metal[i]
    for i in range(len(Metal)):
        Metal[i]=Metal[i]/massemet
    for i in range(len(Silicate)):
        Silicate[i]=Silicate[i]/massesil
    
    return(Metal,Silicate)
debut=time.time()
TestM,TestSil=Compoimpact(m_sil[0],m_met[0],Composil1,Compomet1,KdNi[0],KdCo[0],KdSi[0],KdV[0],KdCr[0],KdO[0])
#print('Test Métal: '+str(TestM))
#print('Test SIlicate; '+str(TestSil))
"On lance la purée!"
Metal=np.zeros([len(frac),len(Compomet1)])
Silicate=np.zeros([len(frac),len(Composil1)])
for i in range(len(frac)):
    if frac[i]<cut:
        metal,silicate=Compoimpact(m_sil[i],m_met[i],Composil1,Compomet1,KdNi[i],KdCo[i],KdSi[i],KdV[i],KdCr[i],KdO[i])
        for j in range(len(Compomet1)):
            Metal[i][j]=metal[j]
        for j in range(len(Composil1)):
            Silicate[i][j]=silicate[j]
    else:
        metal,silicate=Compoimpact(m_sil[i],m_met[i],Composil2,Compomet2,KdNi[i],KdCo[i],KdSi[i],KdV[i],KdCr[i],KdO[i])
        for j in range(len(Compomet1)):
            Metal[i][j]=metal[j]
        for j in range(len(Composil1)):
            Silicate[i][j]=silicate[j]
#print(Metal)
#print(Silicate)
"Calcul de la composition du manteau pour chaque pas d'accrétion"
Compomantle=np.zeros([len(Composil1),len(frac)]) # inversion du sens qui facilite le plot
Compocore=np.zeros([len(Compomet1),len(frac)]) #mélange noyau
Metalplot=np.zeros([len(Compomet1),len(frac)]) #pour plotter
"Premiere étape on a la compo directement"
for i in range(len(Composil1)):
    Compomantle[i][0]=Silicate[0][i]
    
for i in range(1,len(frac)): #cesera les lignes de SIlicate, colonnes de Compomantle déjà initié
    for j in range(len(Composil1)): #lignes de COmpomantle, colonnes de Silicates
           Compomantle[j][i]=(m_manteauacc[i-1]*Compomantle[j][i-1] + m_sil[i]*Silicate[i][j])/m_manteauacc[i]
for i in range(len(Compomet1)):
    Compocore[i][0]=Metal[0][i]
    Metalplot[i][0]=Metal[0][i]
for i in range(1,len(frac)): #cesera les lignes de SIlicate, colonnes de Compomantle déjà initié
    for j in range(len(Compomet1)): #lignes de COmpomantle, colonnes de Silicates
           Compocore[j][i]=(m_noyauacc[i-1]*Compocore[j][i-1] + m_met[i]*Metal[i][j])/m_noyauacc[i]
           Metalplot[j][i]=Metal[i][j]

plt.figure()
plt.title('Mantle: major elements')
plt.plot(frac,Compomantle[0][:]*100)
plt.plot(frac,Compomantle[3][:]*100)
plt.plot(frac,Compomantle[6][:]*100)
plt.plot(frac,Compomantle[7][:]*100)
plt.plot(frac,Compomantle[8][:]*100)
plt.legend(['FeO','SiO2','AlO3/2','CaO','MgO'])
plt.ylabel('% wt')
plt.xlabel('Accreted Fraction')
plt.close()
plt.figure()
plt.title('Mantle: Trace elements')
plt.plot(frac,Compomantle[1][:]*100)
plt.plot(frac,Compomantle[2][:]*100)
#plt.plot(frac,Compomantle[4][:]*100)
#plt.plot(frac,Compomantle[5][:]*100)
plt.legend(['NiO','CoO','VO3/2','CrO'])
plt.ylabel('% wt')
plt.xlabel('Accreted Fraction')
plt.close()
plt.figure()
plt.title('Core: Light element global concentration')
plt.plot(frac,Compocore[3][:]*100)
plt.plot(frac,Compocore[6][:]*100)
#plt.plot(frac,Compomantle[4][:]*100)
#plt.plot(frac,Compomantle[5][:]*100)

plt.legend(['Si','O','VO3/2','CrO'])
plt.ylabel('% wt')
plt.xlabel('Accreted Fraction')
plt.close()
plt.figure()
plt.title('Core: Light element stratified core')
plt.plot(Rn*1e-3,Metalplot[3][:]*100)
plt.plot(Rn*1e-3,Metalplot[6][:]*100)
#plt.plot(frac,Compomantle[4][:]*100)
#plt.plot(frac,Compomantle[5][:]*100)
plt.legend(['Si','O','VO3/2','CrO'])
plt.ylabel('% wt')
plt.xlabel('Core radius')
plt.close()
"On peut créer les rho0 associés à Metal puis calculer Tcmb et T noyau"
"initialisation de rho0 et de l'accrétion"
rho0acc=np.zeros(len(frac))
rho0th=[7019,7900,8900,2210,6100,7190,365.45] #on se fait pas trop chier au début avec les interactions
rho0m=[7019,7900,2210,2550,2000] #Données de Anderson & Ahrens, Brillo & Egry, Kress 2008, Dumay 1995
interaction=[-113.14,-48.439,-732]
alphaSi=-0.91
alphaO=-1.3
#ordre des element: Fe, Ni, Co, Si, V, Cr, O
for i in range(len(frac)):
#    for j in range(len(Metal[0])):
    rhoint=rho0th[0]*Metal[i][0]+rho0th[1]*Metal[i][1]+rho0th[2]*Metal[i][2]+rho0th[4]*Metal[i][4]+rho0th[5]*Metal[i][5]
    rho0acc[i]= rhoint*np.exp(alphaSi*Metal[i][3])*np.exp(alphaO*Metal[i][6])
plt.figure()
plt.title('Densité initiale métal')
plt.plot(frac,rho0acc)
plt.close()
"Fonctions de base: Pression et densité"
def Pressioncore(R,Pn): #deff d'une focntion pression dans le noyau. R en mêtres
    P=364e9+((Pn-364e9)/Rnf**2)*R**2
    return(P)
def rho_poly(P,coeff):
    ratio_poly=np.zeros(len(P))
    for i in range(len(P)):
        ratio_poly[i]=coeff[2]*1+coeff[1]*(P[i]*1e-9)+ coeff[0]*(P[i]*1e-9)**2
        
    return(ratio_poly)
def rhofinal(Pn,Pfinal,rho_init,coeffrho,rho0):
    rhofinal=np.zeros(len(Pfinal))
    for i in range(len(Pfinal)):
    #rhofinal[i]=rho_init[i]*(coeffrho[0]*((Pfinal[i]-Pn[i])*1e-9)**2+coeffrho[1]*((Pfinal[i]-Pn[i])*1e-9))
        rhofinal[i]=rho_init[i]+ rho0[i]*coeffrho[1]*(Pfinal[i]*1e-9-Pn[i]*1e-9)+ rho0[i]*coeffrho[0]*((Pfinal[i]*1e-9)**2-(Pn[i]*1e-9)**2)
    return(rhofinal)
"Fonction température: analytique pour la TCMB, "
def T_simpleanalytique(Px,Tx,Pn,coeff,rho0):
    T_cmb=np.zeros(len(Pn))
    rho_init= np.zeros(len(Pn))
    Px=Px*1e-9
    Pn=Pn*1e-9
    for i in range(len(Pn)):
        haut= (coeff[0]*(Pn[i]**2)+coeff[1]*Pn[i]+coeff[2])
        bas = (coeff[0]*(Px[i]**2)+coeff[1]*Px[i]+coeff[2])
        fact= haut/bas
#        print(fact)
        T_cmb[i]=Tx[i]*(fact**gamma0)
        rho_init[i]=rho0[i]*haut
    return(T_cmb,rho_init)
def Tfinal_EOS2nd(Tcmb,coeff,step,rho0m,rho_init,Pn):
    Pfinal= Pressioncore(Rn,Pn) #en Pa
    nstep=int(step)-1
    Tfinal=np.zeros(len(Tcmb))
    'calcul par trapèze'
    for i in range(len(Tcmb)):
        p1=np.linspace(Pn[i],Pfinal[i],nstep)
        rho_CMB=rho_init
        I= 0
        #calcul de l'intégrale
        for j in range(nstep-1):
            rho1=rho_CMB[i]+ rho0m[i]*coeff[0]*((p1[j]*1e-9)**2 - (Pn[i]*1e-9)**2) + rho0m[i]*coeff[1]*(p1[j]*1e-9 - Pn[i]*1e-9)
            rho2=rho_CMB[i]+ rho0m[i]*coeff[0]*((p1[j+1]*1e-9)**2 - (Pn[i]*1e-9)**2) + rho0m[i]*coeff[1]*(p1[j+1]*1e-9 - Pn[i]*1e-9)
            I = I+((1/rho1)+(1/rho2))*((p1[j+1]-p1[j]))/2
        Tfinal[i] = Tcmb[i]*np.exp((alpha/(Cpm))*I)
    return(Tfinal)
"On reprend les fonctions, mais pas besoin du rho0 compliqué, car fixé par l'accrétion"
def calculTemperature(coeff_norm,step,Rn,frac,Px,Tx,Pn,rho0): #coeff de l'EOS, step pour l'int,Rayon noyau, pas d'accrétion, Pmo,Tmo, Pression CMB, rho0 du métal
        Tcmbsimple=[] #initialisation des variables sans mélanges
        rhoinitsimple=[]
        Tfinalsimple=[]
        rhofinalsimple=[]
        Pfinal=Pressioncore(Rn,Pn)
        for i in range(len(frac)):
            Tcmb,rhoinit=T_simpleanalytique(Px,Tx,Pn,coeff_norm,rho0) #rhoinit= rho à la CMB au moment de l'accrétion
            Tcmbsimple.append(Tcmb)
            rhoinitsimple.append(rhoinit)
            rhofin=rhofinal(Pn,Pfinal,rhoinit,coeff_norm,rho0)
            rhofinalsimple.append(rhofin)
            Tfin=Tfinal_EOS2nd(Tcmb,coeff_norm,step,rho0,rhoinit,Pn)
            Tfinalsimple.append(Tfin)
        return(Tcmbsimple,Tfinalsimple,rhofinalsimple)

Testcmb,testrho=T_simpleanalytique(P50,T50,PCMB,coeff_norm,rho0acc)
Tfinaltest=Tfinal_EOS2nd(Testcmb,coeff_norm,300,rho0acc,testrho,PCMB)
Tcmbsimple,Tfinalsimple,rhofinalsimple=calculTemperature(coeff_norm,300,Rn,frac,P50,T50,PCMB,rho0acc)
fin=time.time()
temps=fin-debut
plt.figure()
plt.title('densité au début et à la fin')
plt.plot(frac,testrho)
plt.plot(frac,rhofinalsimple[5])
plt.close()
plt.figure()
plt.title('T CMB accrétée')
plt.plot(frac,Testcmb)
plt.plot(frac,Tfinaltest)
plt.legend(['T CMB','T final'])
plt.ylabel('T in K')
plt.xlabel('Frac accreted')
plt.close()
"Calcul avec mélange à chaque étape"
def compomelange(m_manteauacc,m_sil,m_met,composil_imp,compomet_imp,KdNi,KdCo,KdSi,KdV,KdCr,KdO,frac):
    Silicate=np.zeros([len(frac),len(composil_imp[0])]) #ligne en point d'accrétion
    Metal=np.zeros([len(frac),len(compomet_imp[0])]) 
    Silicateplot=np.zeros([len(composil_imp[0]),len(frac)]) #plus facile à plotter
    Metalplot=np.zeros([len(compomet_imp[0]),len(frac)]) #plus facile à plotter
    #Initialisation : temps 0
    
    Met,Sil=Compoimpact(m_sil[0],m_met[0],composil_imp[0],compomet_imp[0],KdNi[0],KdCo[0],KdSi[0],KdV[0],KdCr[0],KdO[0])
    for i in range(len(Sil)):
        Silicate[0][i]=Sil[i]
    for i in range(len(Met)):
        Metal[0][i]=Met[i]
    #Mélange du silicate
    Composilmixed=np.zeros(len(Sil))
    for i in range(1,len(frac)): #calcul pour tout sauf le premier pas d'accrétion
        # On calcule la compo du silicate en input
        for j in range(len(composil_imp[0])):
            Composilmixed[j]= (Silicate[i-1][j]*m_manteauacc[i-1] + composil_imp[i][j]*m_sil[i])/m_manteauacc[i]
        
        Met,Sil=Compoimpact(m_sil[i],m_met[i],Composilmixed,compomet_imp[i],KdNi[i],KdCo[i],KdSi[i],KdV[i],KdCr[i],KdO[i]) #Calcul de la compo
        for j in range(len(Sil)):
            Silicate[i][j]=Sil[j]
        for j in range(len(Met)):
            Metal[i][j]=Met[j]
    # on inverse ligne et colonnes
    for i in range(len(frac)):
        for j in range(len(composil_imp[0])):
            Silicateplot[j][i]=Silicate[i][j]
        for j in range(len(compomet_imp[0])):
            Metalplot[j][i]=Metal[i][j]
    return(Metal,Silicate,Metalplot,Silicateplot)
Metal2,Silicate2,Metalplot,Silicateplot=compomelange(m_manteauacc,m_sil,m_met,Composil_imp,Compomet_imp,KdNi,KdCo,KdSi,KdV,KdCr,KdO,frac)
plt.figure()
plt.title('Comparaison Fe: sans mélange/mélange progressif')
plt.plot(frac,Compomantle[0][:]*100)
plt.plot(frac,Silicateplot[0][:]*100)
#plt.plot(frac,Compomantle[3][:]*100)
#plt.plot(frac,Compomantle[6][:]*100)
#plt.plot(frac,Compomantle[7][:]*100)
#plt.plot(frac,Compomantle[8][:]*100) 
#plt.legend(['FeO','SiO2','AlO3/2','CaO','MgO'])
plt.legend(['FeO-no mix','FeO mixed'])
plt.ylabel('% wt')
plt.xlabel('Accreted Fraction')
plt.close()
plt.figure()
plt.title('Comparaison Si: sans mélange/mélange progressif')
plt.plot(frac,Compomantle[3][:]*100)
plt.plot(frac,Silicateplot[3][:]*100)
#plt.plot(frac,Compomantle[3][:]*100)
#plt.plot(frac,Compomantle[6][:]*100)
#plt.plot(frac,Compomantle[7][:]*100)
#plt.plot(frac,Compomantle[8][:]*100) 
#plt.legend(['FeO','SiO2','AlO3/2','CaO','MgO'])
plt.legend(['SiO2-no mix','SiO2 mixed'])
plt.ylabel('% wt')
plt.xlabel('Accreted Fraction')
plt.close()
"On passe aux calculs de TCMB"
"On fait un modèle d'accrétion en compo moyenne"
"initialisation de rho0 et de l'accrétion"
rho0moyen=np.zeros(len(frac))
rho0th=[7019,7900,8900,2210,6100,7190,365.45] #on se fait pas trop chier au début avec les interactions
rho0m=[7019,7900,2210,2550,2000] #Données de Anderson & Ahrens, Brillo & Egry, Kress 2008, Dumay 1995
interaction=[-113.14,-48.439,-732]
alphaSi=-0.91
alphaO=-1.3
#ordre des element: Fe, Ni, Co, Si, V, Cr, O
for i in range(len(frac)):
    rhoint=rho0th[0]*Compocore[0][19]+rho0th[1]*Compocore[1][19]+rho0th[2]*Compocore[2][19]+rho0th[4]*Compocore[4][19]+rho0th[5]*Compocore[5][19]
    rho0moyen[i]= rhoint*np.exp(alphaSi*Compocore[3][19])*np.exp(alphaO*Compocore[6][19])
#print(rho0moyen)
"Calcul de T"
TCMBmoyen,rhomoyen=T_simpleanalytique(P50,T50,PCMB,coeff_norm,rho0moyen)
Tfinalmoyen=Tfinal_EOS2nd(TCMBmoyen,coeff_norm,300,rho0moyen,rhomoyen,PCMB)
Pfinal=Pressioncore(Rn,PCMB)
rhofintest=(coeff_norm[0]*((Pfinal*1e-9)**2)+coeff_norm[1]*Pfinal*1e-9+coeff_norm[2])*rho0acc
rhofinmoyen=(coeff_norm[0]*((Pfinal*1e-9)**2)+coeff_norm[1]*Pfinal*1e-9+coeff_norm[2])*rho0moyen
"Figure"
plt.figure()
plt.title('T pour compo moyenne')
plt.plot(frac,TCMBmoyen,'b')
plt.plot(frac,Tfinalmoyen,'r')
plt.plot(frac,Testcmb,'g')
plt.plot(frac,Tfinaltest,'y')
plt.legend(['T CMB','T finale','T CMB strati','T fin strati'])
plt.close()
plt.figure()
plt.plot(frac,rhofintest)
plt.plot(frac,rhofinmoyen)
plt.close()
"definition de l'netropie"
def Entropiesimple(T,rho,R): #fonction d'intégration sur les step qu'on a déjà. 
    S=0 #entropie en Joule, donnée par l'intégrale * 4piCpm
    I = 0 #intégrale
    for i in range(len(T)-1):
        fact1=T[i]*rho[i]*R[i]**2
        fact2=T[i+1]*rho[i+1]*R[i+1]**2
        I = I +(fact1+fact2)*(R[i+1]-R[i])/2
    S=S+4*np.pi*Cpm*I
    return(S)

#print('Energie mélange isentropique simple='+str(Q_simple))
#print('Energie mélange isentropique moyenne='+str(Q_moy))

"Calcul de la T_cmb à entropie constante"

def CMBisentrope(rho,gamma,R): #fonction d'intégration
    rho_cmb=rho[len(rho)-1]
    I=0
    for i in range(len(rho)-1):
        fact1=(R[i]**2)*(rho[i]/rho_cmb)**(gamma+1)
        fact2=(R[i+1]**2)*(rho[i+1]/rho_cmb)**(gamma+1)
        I=I+(fact1+fact2)*(R[i+1]-R[i])/2
    I_totale=4*np.pi*rho_cmb*Cpm*I
    return(I_totale)
"Calcul des isentropes  "

Qsimple=0
Qmelange=0

    
Q=Entropiesimple(Tfinaltest,rhofintest,Rn)
Qm=Entropiesimple(Tfinalmoyen,rhofinmoyen,Rn)
integ=CMBisentrope(rhofinmoyen,gamma0,Rn)
Tcmbisentrope=Q/integ
integm=CMBisentrope(rhofinmoyen,gamma0,Rn)
Tcmbisentropemoyen=Qm/integm
"Formation d'un profil isentropique"
Tisentrope=np.zeros(len(frac))
Tisentropemoyen=np.zeros(len(frac))
for i in range(len(frac)):
#    print(rhofintest[i])
    Tisentrope[i]=Tcmbisentrope*(rhofintest[i]/rhofintest[19])**gamma0
    Tisentropemoyen[i]=Tcmbisentropemoyen*(rhofinmoyen[i]/rhofinmoyen[19])**gamma0
plt.figure()
plt.plot(frac,Tisentrope)
plt.plot(frac,Tfinaltest)
plt.legend(['Isentrope','T normale'])
plt.title('Isentrope vs T noyau-stratifié')
plt.close()
plt.figure()
plt.plot(frac,Tisentropemoyen)
plt.plot(frac,Tfinalmoyen)
plt.legend(['Isentrope','T normale'])
plt.title('Isentrope vs T noyau-mélangé')
plt.close()
plt.figure()
plt.plot(frac,Tisentrope)
plt.plot(frac,Tisentropemoyen)
plt.legend(['Stratifié','Mélangé'])
plt.title('Strati vs mélangé')
plt.close()
plt.figure()
"Calcul des delta E gravi"
"D'abord g = fonction de R"
"on fait en numérique comme ça on s'emmerde pas"
def gravi(Rn,rho,step):
    G=6.67430*1e-11
    g=np.zeros(len(Rn))
    nstep=int(step-1)
    for i in range(1,len(g)):
        r1=np.linspace(0,Rn[i],nstep)
        rho1=np.linspace(rho[0],rho[i],nstep)
        I=0
        for j in range(len(r1)-1):
            poly1=(rho1[j])*(r1[j])**2
            poly2=(rho1[j+1])*(r1[j+1])**2
            I=I + (poly1+poly2)*(r1[j+1]-r1[j])/2
        g[i]=4*np.pi*G*I/(Rn[i]**2)
    return(g)
gtest1=gravi(Rn,rhofintest,300)
gtest2=gravi(Rn,rhofinmoyen,300)
plt.figure()
plt.plot(Rn*1e-3,gtest1)
plt.plot(Rn*1e-3,gtest2)
plt.legend(['Strati','Melangé'])
plt.close()
"calcul de De/dr"
def dEpot(g,rho):
    Ep=np.zeros(len(g))
    for i in range(len(g)):
        Ep[i]=0.5*g[i]*rho[i]
    return(Ep)
Etest1=dEpot(gtest1,rhofintest)
Etest2=dEpot(gtest2,rhofinmoyen)
plt.figure()
plt.plot(Rn*1e-3,Etest1)
plt.plot(Rn*1e-3,Etest2)
plt.close()
'intégration'
def Epotentielle(Rn,rho,step): 
    E=0
    nstep=int(step)-1
    Itot=0 #integration totale
    for i in range(len(Rn)-1):
        rho1=np.linspace(rho[i],rho[i+1],nstep) #multiplication des points intermédiare
        r1=np.linspace(Rn[i],Rn[i+1],nstep)
        g1=gravi(r1,rho1,step)
        I=0
        for j in range(nstep-1):
            func1= rho1[j]*g1[j]
            func2= rho1[j+1]*g1[j+1]
            I = I + (func1+func2)*(r1[j+1]-r1[j])/2
        Itot=Itot+I
    E=Itot
    return(E)
Emoyen=Epotentielle(Rn,rhofinmoyen,300)
Estrati=Epotentielle(Rn,rhofintest,300)